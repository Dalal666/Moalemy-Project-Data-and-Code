import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

const withAuthRedirect = (WrappedComponent) => {
  return (props) => {
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const user = typeof window !== 'undefined' ? JSON.parse(localStorage.getItem('user')) : null;

    useEffect(() => {
      if (user && router.pathname === '/') {
        setLoading(true);
        if (user.email === "admin@email.com") {
          router.replace('/admin'); // Redirect to admin page
        } else {
          router.replace('/dashboard'); // Redirect to dashboard
        }
      } else {
        setLoading(false);
      }
    }, [user, router]);

    if (loading) {
      return (
        <div className="flex items-center justify-center h-screen">
          <div className="w-16 h-16 border-t-4 border-b-4 border-blue-500 rounded-full animate-spin"></div>
        </div>
      );
    }

    return <WrappedComponent {...props} />;
  };
};

export default withAuthRedirect;