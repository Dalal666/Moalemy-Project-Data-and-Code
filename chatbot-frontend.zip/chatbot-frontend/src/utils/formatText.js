export const formatText = (text) => {
  if (!text) return "";
  const formattedText = text
  .replace(/▪/g, "▪")
  .replace(/•/g, "•")
    .replace(/(\d+)\./g, "$1.")
   .replace(
      /([\u0600-\u06FF]+.*?)([A-Za-z0-9 ]+)/g,
      '$1<span dir="ltr">$2</span>' // Wrap English text in LTR spans
    ).replace(/(\r\n|\n|\r)/g, "<br/>");

  console.log(formattedText);
  return  `<div dir="rtl">${formattedText}</div>`;;
  };
// export const formatText = (text) => {
//   if (!text) return "";
//   const formattedText = text
//     .replace(/•/g, "<li>•")
//     .replace(/(\d+)\./g, "<li>$1.")
//     .replace(/(\r\n|\n|\r)/g, "<br/>")
//     .replace(/<li>/g, "<li style='list-style-type: disc; margin-left: 20px;'>");

//   console.log(formattedText);
//   return `<ul>${formattedText}</ul>`;
// };