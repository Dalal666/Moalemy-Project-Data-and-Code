const chapterNames = [
  "التعليم الإلكتروني",
  "البيانات والمعلومات",
  "الأجهزة والبرمجيات",
  "الشبكة والويب",
  "نظم التشغيل وقواعد البيانات",
  "أمن المعلومات",
];
export const formatChapter = (chapterNumber) => {
  let chapterName = chapterNames[chapterNumber-1];
  return chapterName;
};
