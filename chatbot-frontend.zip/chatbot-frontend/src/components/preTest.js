import React, { useState, useEffect, useRef } from "react";
import { pretestQuestions } from "@/data/CourseData";
import { LuClock4 } from "react-icons/lu";
import { Navigation } from "./navigation";
import QuestionCard from "./questionCard";
import { ProgressCircle } from "./progressCircle";
import { formatChapter } from "../utils/functions";
import { useRouter } from "next/router";
import axios from "axios";
import { useNextStep } from "nextstepjs";


export default function PreTest({ handleSubmit }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const allChapters = [1, 2, 3, 4, 5, 6];
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [user, setUser] = useState(null);
  const [userMethod, setUserMethod] = useState(null);
  const { startNextStep, closeNextStep, currentTour } = useNextStep();

  // Auto-start the tour when the page loads (if not already started)
  useEffect(() => {
    startNextStep("mainTour");

  }, [startNextStep]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        router.replace("/"); // Redirect to home page if storedUser is not defined
      } else {
        setUser(JSON.parse(storedUser));
        setUserMethod(JSON.parse(storedUser).method);
      }
    }
  }, [router]);

  const totalQuestions = pretestQuestions.length;
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState(Array(totalQuestions).fill(null));
  const [timeLeft, setTimeLeft] = useState(200);
  const [score, setScore] = useState(0);

  const [weakChapters, setWeakChapters] = useState([]);
  const [completeTest, setCompleteTest] = useState(false);
  const [endMsg, setEndMsg] = useState(false);
  const filterChapters = allChapters.filter(
    (item) => !weakChapters.includes(item)
  );
  console.log(user, "2");
  const [checkedState, setCheckedState] = useState(
    userMethod === 2
      ? new Array(allChapters.length - 1).fill(false)
      : new Array(
        filterChapters.length > 0 ? filterChapters.length - 1 : 0
      ).fill(false)
  );

  const [isLoading, setisLoading] = useState(false);
  const [error, setError] = useState({
    isError: false,
    msg: "",
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const [chapterScores, setChapterScores] = useState({});

  // Handle answer
  const handleAnswer = (choice) => {
    const question = pretestQuestions[currentQuestionIndex];
    const chapter = question.ch;

    const updatedAnswers = [...answers];
    updatedAnswers[currentQuestionIndex] = choice;
    setAnswers(updatedAnswers);

    if (question.choices[question.answer] === choice) {
      setScore((prev) => prev + 1);

      setChapterScores((prevScores) => {
        const updatedScores = { ...prevScores };
        updatedScores[chapter] = (updatedScores[chapter] || 0) + 1;
        return updatedScores;
      });
    } else {
      !weakChapters.includes(chapter) &&
        setWeakChapters((state) => [...state, +chapter].sort());
    }

    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      submitPretest();
      setCompleteTest(true);
    }
  };

  const chapterNames = {
    1: "التعليم الإلكتروني",
    2: "البيانات والمعلومات",
    3: "الأجهزة والبرمجيات",
    4: "الشبكة والويب",
    5: "قاعدة البيانات ونظم التشغيل",
    6: "أمن المعلومات",
  };

  const calculateChapterResults = () => {
    const results = [];

    // Group questions by chapter
    const questionsPerChapter = pretestQuestions.reduce((acc, question) => {
      const chapter = question.ch;
      acc[chapter] = (acc[chapter] || 0) + 1;
      return acc;
    }, {});

    // Calculate scores
    Object.keys(questionsPerChapter).forEach((chapter) => {
      const total = questionsPerChapter[chapter];
      const correct = chapterScores[chapter] || 0;
      const percentage = ((correct / total) * 100).toFixed(2);

      let grade = "F";
      if (percentage >= 90) grade = "A";
      else if (percentage >= 75) grade = "B";
      else if (percentage >= 50) grade = "C";
      else if (percentage >= 35) grade = "D";

      results.push({
        chapter,
        name: chapterNames[chapter] || `شابتر ${chapter}`, // Use Arabic name or fallback
        percentage,
        grade,
      });
    });

    return results;
  };

  const handleNavigate = (index) => {
    if (index >= 0 && index < totalQuestions && timeLeft > 0) {
      setCurrentQuestionIndex(index);
    }
  };

  const handleSelectMethod = (value) => {
    if (value === 5) {
      setEndMsg(true);
      return;
    }
    setUserMethod(value);
    setEndMsg(true);
  };

  const submitPretest = async () => {
    setisLoading(true);
    setError({ isError: false, msg: "" });

    const userChapters = [];
    const checkedCheckboxes = Object.keys(checkedState).filter(
      (checkbox) => checkedState[checkbox]
    );

    for (let i = 0; i < checkedCheckboxes.length; i++) {
      if (userMethod === 2)
        userChapters.push(allChapters[+checkedCheckboxes[i]]);
      else userChapters.push(filterChapters[+checkedCheckboxes[i]]);
    }
    try {
      console.log("new usee", user.method);
      const response = await axios.put("https://backend-chatbot.nousheen-solutions.com/api/update", {
        email: user.email,
        username: user.username,
        password: user.password,
        method: user.method,
        weak_chapters: weakChapters,
        pretest_score_before: score,
        user_chapters: userChapters,
      });
      user["progress"] = 8;
      localStorage.setItem("user", JSON.stringify(response.data));
      // handleSubmit();
      //window.location.replace("/learn/" + user.method);

      setisLoading(false);
    } catch (error) {
      setisLoading(false);
      setError({ isError: true, msg: "حدث خطأ ما!" });
      console.error(" failed:", error);
    }
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };
  console.log(user);
  return (
    <div className='flex flex-col justify-between max-w-2xl w-[800px] p-6 space-y-4 shadow-lg bg-white bg-[url("/looper.svg")] bg-left h-[400px] rounded-lg'>
      {!completeTest ? (
        <>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-x-1">
              <LuClock4 className="text-2xl leading-none" />
              <div className="flex flex-col font-semibold">
                <span className="text-sm font-bold leading-5">
                  {formatTime(timeElapsed)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <ProgressCircle
              currentIndex={answers.filter((answer) => answer !== null).length}
              totalQuestions={totalQuestions}
            />
            <QuestionCard
              questions={[pretestQuestions[currentQuestionIndex]]}
              selectedAnswer={answers[currentQuestionIndex]}
              handleAnswer={handleAnswer}
              showExplanation={false}
            />
          </div>

          <Navigation
            totalQuestions={totalQuestions}
            currentIndex={currentQuestionIndex}
            answeredQuestions={answers.map((answer) => answer !== null)}
            onNavigate={handleNavigate}
            isPreTest={true}
          />
        </>
      ) : (
        <>
          <div className="mt-6">
            <div className="w-full flex justify-between">
              <button
                onClick={handleSubmit}
                className="px-4 py-2 text-white transition duration-300 rounded-lg shadow-md bg-pepsi-blue hover:bg-blue-700"
              >
                التالي
              </button>
              <h2 className="text-xl font-bold mb-4">نتائج الاختبار السابق</h2>
            </div>
            <table className="w-full border-collapse border border-gray-300 text-right">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">التقدير</th>
                  <th className="border border-gray-300 px-4 py-2">النسبة</th>
                  <th className="border border-gray-300 px-4 py-2">
                    اسم الفصل
                  </th>
                  <th className="border border-gray-300 px-4 py-2">الفصل</th>
                </tr>
              </thead>
              <tbody>
                {calculateChapterResults().map((result, index) => (
                  <tr key={index} className="text-right">
                    <td className="border border-gray-300 px-4 py-2">
                      {result.grade}
                    </td>
                    <td className="border border-gray-300 px-4 py-2">
                      {result.percentage}%
                    </td>
                    <td className="border border-gray-300 px-4 py-2">
                      {result.name}
                    </td>
                    <td className="border border-gray-300 px-4 py-2">
                      {parseInt(result.chapter).toLocaleString("ar-EG")}
                    </td>

                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      {currentTour && (
        <button
          onClick={closeNextStep}
          className="fixed bottom-4 right-4 z-50 p-2 bg-red-500 text-white rounded-full shadow-md"
        >
          جولة قريبة
        </button>
      )}
    </div>
  );
}
