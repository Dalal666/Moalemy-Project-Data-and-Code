import React, { useState } from "react";
import { IoEyeOffOutline, IoEyeSharp } from "react-icons/io5";
import { HiOutlineMail } from "react-icons/hi";
import Link from "next/link"; // Correct import for Link from next/link
import { useRouter } from "next/router"; // Correct import for useRouter from next/router
import axios from "axios";

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setisLoading] = useState(false);
  const [error, setError] = useState({
    isError: false,
    msg: "",
  });
  const router = useRouter();

  const togglePasswordVisibility = () => setShowPassword(!showPassword);
  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  };
  const handleLogin = async (e) => {
    if (!validateEmail(email)) {
      setError({ isError: true, msg: 'البريد الإلكتروني غير صحيح' });
      return;
    }
    e.preventDefault();
    setisLoading(true);
    setError({ isError: false, msg: "" });

    if (email === 'admin@email.com' && password === 'SuperAdminPassword') {
      localStorage.setItem("user", JSON.stringify({ email: "admin@email.com" }));
      localStorage.setItem("time_start", new Date().getTime());
      localStorage.setItem("method", null);
      window.location.replace("/admin");
    }

    try {
      const response = await axios.post('https://backend-chatbot.nousheen-solutions.com/api/login', {
        email,
        password,
      });

      if (response.data?.length === 0) {
        console.log("error logging in")
        setisLoading(false);
        setError({ isError: true, msg: "خطأ فى البريد الإلكترونى او كلمة المرور غير صحيحة "});
        return;
      }
      localStorage.setItem("user", JSON.stringify(response.data[0]));
      localStorage.setItem("time_start", new Date().getTime());
      localStorage.setItem("method", null);
       window.location.replace("/preTest");
    } catch (error) {
      setisLoading(false);
      setError({ isError: true, msg: "!حدث خطأ ما" });
      console.error('Login failed:', error);
    }
  };

  return (
    <div className="flex items-center justify-center h-full min-h-screen p-4 bg-gray-100 gap-x-10">
      <div className="w-full max-w-sm">
        <form
          onSubmit={handleLogin}
          className="flex flex-col gap-y-8 bg-opacity-85 bg-white px-6 pt-6 pb-10 shadow-[0_2px_16px_-3px_rgba(173, 216, 230, 0.3)]"
        >
          {/* Header */}
          <div className="text-center">
            <h3 className="text-3xl font-extrabold text-gray-800">تسجيل الدخول</h3>
          </div>
          <div className="flex flex-col gap-y-4">
            {/* Email Input */}
            <div className="relative flex flex-row-reverse items-center">
              <input
                name="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-2 py-3 text-sm text-right text-gray-800 bg-transparent border-b border-gray-400 outline-none focus:border-gray-800 placeholder:text-gray-800"
                placeholder="أدخل البريد الإلكتروني"
              />
              <HiOutlineMail className="absolute w-5 h-5 text-gray-600 left-2" />
            </div>

            {/* Password Input */}
            <div className="relative flex flex-row-reverse items-center">
              <input
                name="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-2 py-3 text-sm text-right text-gray-800 bg-transparent border-b border-gray-400 outline-none focus:border-gray-800 placeholder:text-gray-800"
                placeholder="أدخل كلمة المرور"
              />
              <button
                type="button"
                onClick={togglePasswordVisibility}
                className="absolute text-gray-600 transition-transform duration-300 scale-90 left-2 focus:outline-none hover:scale-100"
              >
                {showPassword ? (
                  <IoEyeOffOutline className="w-5 h-5" />
                ) : (
                  <IoEyeSharp className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          {/* Remember Me and Forgot Password */}
          <div className="flex flex-wrap items-center justify-end gap-4 text-right">
            <div className="flex flex-row-reverse items-center">
              <input
                id="remember-me"
                name="rememberMe"
                type="checkbox"
                className="w-4 h-4 border-gray-300 rounded shrink-0"
              />
              <label
                htmlFor="remember-me"
                className="block mr-3 text-sm text-gray-800"
              >
                تذكرني
              </label>
            </div>
          </div>

          {/* Submit Button and Register Link */}
          <div className="space-y-8">
            <button
              type="submit"
              className="w-full py-2.5 px-4 text-sm font-semibold tracking-wider rounded-full text-white bg-gray-800 focus:outline-none transform transition duration-300 scale-90 hover:scale-100"
            >
              تسجيل الدخول
            </button>
              {error.isError && (
              <div className="flex justify-center items-center p-2 mb-4 text-red-500 border border-red-500 rounded">
                {error.msg}
              </div>
            )}
            <p className="text-sm text-right text-gray-800">
              ليس لديك حساب؟
              <Link
                href="/signup"
                className="mr-1 font-semibold text-pepsi-blue hover:underline"
              >
                قم بالتسجيل هنا
              </Link>
            </p>
          </div>
        </form>
      </div>
      <div className='bg-pepsi-blue bg-[url("/looper.svg")] bg-no-repeat bg-contain bg-left rotate-180 max-w-md w-full h-[440px]'></div>
    </div>
  );
};

export default Login;