import React, { useState, useEffect } from "react";
import { MdWavingHand, MdTrackChanges } from "react-icons/md";
import { GiStaticWaves } from "react-icons/gi";
import { RxMix } from "react-icons/rx";
import { formatChapter } from "../utils/functions";
import { MdOutlineDynamicForm } from "react-icons/md";
import { useRouter } from "next/router";
import axios from "axios";

export default function CardsScreen() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const allChapters = [1, 2, 3, 4, 5, 6];
  const [username, setUsername] = useState("");
  const [method, setMethod] = useState(null); // Stores the selected method.
  const [checkedChapters, setCheckedChapters] = useState([]); // Stores selected chapters.
  const [showChapters, setShowChapters] = useState(false); // Determines whether to show chapter selection.
  const [nextEnabled, setNextEnabled] = useState(false); // Enables "Next" button conditionally.
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        router.replace("/"); // Redirect to home page if storedUser is not defined
      } else {
        const parsedUser = JSON.parse(storedUser);
        setUsername(parsedUser.username); // Set username directly from parsed user
        console.log("Parsed User:", parsedUser); // Log parsed user
        setUser(parsedUser);
      }
    }
  }, [router]);
  const cards = [
    {
      title: "Adaptive",
      icon: <MdTrackChanges />,
      id: 3,
    },
    {
      title: "Static",
      icon: <GiStaticWaves />,
      id: 1,
    },
    {
      title: "Mixed",
      icon: <RxMix />,
      id: 4,
    },
    {
      title: "Adaptable",
      icon: <MdOutlineDynamicForm />,
      id: 2,
    },
  ];

  // Handles selecting a learning method.
  const handleSelectMethod = (methodId) => {
    console.log(`Selected Method ID: ${methodId}`);
    setMethod(methodId);

    if (methodId === 2) {
      console.log(`Method requires chapter selection: ${methodId}`);
      setShowChapters(true);
      setNextEnabled(false); // Disable "Next" until chapters are selected.
    } else {
      console.log(`Direct method selected: ${methodId}`);
      setShowChapters(false);
      setNextEnabled(true);
    }
  };

  // Handles chapter checkbox toggling.
  const handleChapterSelection = (chapter) => {
    console.log(`Toggling chapter: ${chapter}`);
    const updatedChapters = checkedChapters.includes(chapter)
      ? checkedChapters.filter((ch) => ch !== chapter)
      : [...checkedChapters, chapter];
    console.log(`Updated chapters: ${updatedChapters}`);
    setCheckedChapters(updatedChapters);
    console.log("ok", updatedChapters);
    setNextEnabled(updatedChapters.length > 0); // Enable "Next" if chapters are selected.
  };

  // Handles "Next" button functionality.
  const handleClickNext = async () => {
    console.log("Next button clicked.");
    console.log(`Selected method: ${method}`);
    console.log(
      `Selected chapters: ${method === 2 ? checkedChapters : allChapters}`
    );
    const user = JSON.parse(localStorage.getItem("user"));

    try {
      const payload = {
        email: user.email,
        username: user.username,
        password: user.password,
        method,
        user_chapters: method === 2 ? checkedChapters : [],
      };
      console.log("Payload to be sent:", payload);
      const response = await axios.put(
        "https://backend-chatbot.nousheen-solutions.com/api/update",
        payload
      );
      console.log("Server response:", response);
      localStorage.setItem("user", JSON.stringify(response.data));
      window.location.replace(`/learn/${method}`);
    } catch (error) {
      console.error("Error updating method:", error);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center w-screen">
      <div className="flex flex-col items-center justify-center gap-y-4">
        <div className="p-3 rounded-lg bg-pepsi-blue">
          <MdWavingHand className="text-3xl text-white" />
        </div>
        <div className="flex flex-col items-center gap-1">
          <h1 className="text-lg font-medium text-gray-500">
            {username}، مرحبًا
          </h1>
          <p className="text-2xl font-bold leading-8 text-gray-600">
            أهلاً بك في شات بوت معلمي
          </p>
          <p className=" text-sm text-center text-gray-500">
            :اختاري طريقة التعلم التي ترغبين من التالي
          </p>
        </div>
      </div>

      {/* Cards for selecting methods */}
      <div className="grid grid-cols-2 gap-4 mt-6">
        {cards.map((card, index) => (
          <div
            key={index}
            onClick={() => handleSelectMethod(card.id)}
            className={`flex gap-x-2 items-center bg-white p-4 rounded-lg shadow-md w-60 cursor-pointer transition-transform duration-300 ${
              method === card.id
                ? "ring-2 ring-pepsi-blue"
                : "hover:translate-x-2"
            }`}
          >
            <div className="flex items-center justify-center w-8 h-8 text-lg text-white rounded-md bg-pepsi-blue ">
              {card.icon}
            </div>
            <div>
              <p className="font-semibold ">{card.title}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Chapter selection if needed */}
      {showChapters && (
        <div className="flex flex-col space-y-1 w-85 mt-6">
          <p className="mb-1 mr-12 font-medium text-gray-600 text-right">
            : اختاري الفصول التي تريدين تعلمها
          </p>
                  <div className="  flex flex-col items-end gap text-right">
            {allChapters.map((chapter, index) => (
              <label
                key={chapter}
                className="flex items-center cursor-pointer gap-x-2 rtl:text-right"
                >
                    <span className="text-gray-600">
                        {`الفصل ${(index + 1).toLocaleString(
                            "ar-EG"
                        )} : ${formatChapter(chapter)} `}
                    </span>
                <input
                  type="checkbox"
                  value={chapter}
                  checked={checkedChapters.includes(chapter)}
                  onChange={() => handleChapterSelection(chapter)}
                        className="accent-pepsi-blue"
                  
                />
                
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Next Button */}
      {nextEnabled && (
        <button
          onClick={handleClickNext}
          className="px-6 py-2 mt-3 text-white transition duration-300 rounded-lg shadow-md bg-pepsi-blue hover:bg-blue-700"
        >
          التالي
        </button>
      )}
    </div>
  );
}
