import { useEffect, useRef } from 'react';
import { useRouter } from 'next/router';

export function Navigation({
  totalQuestions,
  currentIndex,
  answeredQuestions,
  onNavigate,
  isPostTest = false, // Add isPostTest prop with default value
  isPreTest = false, // Add isPreTest prop with default value
}) {
  const router = useRouter();
  const currentQuestionRef = useRef(null);

  useEffect(() => {
    if (currentQuestionRef.current) {
      currentQuestionRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [currentIndex]);

  return (
    <div className="flex flex-row-reverse items-center justify-between w-full gap-4">
      <button
        onClick={() => onNavigate(currentIndex - 1)}
        disabled={currentIndex === 0 || (isPostTest || isPreTest)} // Disable if post-test
        className="border-[1px] border-blue-950 font-semibold text-sm text-gray-800 px-3 py-2 rounded-md"
      >
        السابق
      </button>

      <div className="flex flex-row-reverse gap-2 overflow-x-auto" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
        {Array.from({ length: totalQuestions }).map((_, index) => (
          <button
            key={index}
            ref={index === currentIndex ? currentQuestionRef : null}
            onClick={() => (!isPostTest && !isPreTest) && onNavigate(index)} // Restrict navigation if post-test
            className={`w-8 h-8 rounded-md border-[1.5px] shadow-sm ${
              index === currentIndex
                ? "bg-gradient-to-r from-[#5899E2] to-pepsi-blue text-white"
                : answeredQuestions[index]
                ? "bg-pepsi-blue text-white"
                : "bg-white text-black"
            }`}
            style={{ flexShrink: 0 }}
          >
            {index + 1}
          </button>
        ))}
      </div>

      <button
        onClick={() => onNavigate(currentIndex + 1)}
        disabled={
          currentIndex === totalQuestions - 1 ||
          !answeredQuestions[currentIndex]
        }
        className={`rounded-md border-[1.5px] text-sm text-gray-800 px-3 py-2 font-semibold ${
          answeredQuestions[currentIndex] ? " border-blue-950 " : ""
        }`}
      >
        التالي
      </button>
    </div>
  );
}