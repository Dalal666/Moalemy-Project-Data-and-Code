
import React from "react";
import { formatText } from "../utils/formatText";
const QuestionCard = ({ questions, selectedAnswer, handleAnswer, showExplanation, showCorrectAnswer }) => {
  
  return (
    <div className="w-full space-y-6">
      
      {questions.map((item, index) => {
        // Log the question and its choices to the console
        console.log("Question:", item.content);
        // console.log("Choices:", item.choices);

        return (
          <div key={index} className="flex flex-col items-end gap-4 text-right">
            <span className="block text-base font-semibold">
                         <div dangerouslySetInnerHTML={{ __html: formatText(item.content) }} />
            </span>
            <div className="space-y-2">
             
              {item.choices.map((choice, optionIndex) => (
                <label
                  key={optionIndex}
                  htmlFor={`option-${item.id}-${optionIndex}`}
                  className="flex items-center justify-end gap-2 text-sm"
                >
                  <div dangerouslySetInnerHTML={{ __html: formatText(choice) }} />
                  <input
                    type="radio"
                    name={`question-${item.id}`}
                    id={`option-${item.id}-${optionIndex}`}
                    value={choice}
                    checked={selectedAnswer === choice}
                    onChange={() => handleAnswer(choice)}
        
                    className={`mr-2 ${
                      selectedAnswer === optionIndex ? "bg-blue-500" : ""
                    }`}
                    
                  />
                </label>
              ))}
            </div>
            {showExplanation && selectedAnswer && (
              <div className="mt-4 text-sm text-gray-700">
                <strong>توضيح:</strong> {item.reason}
              </div>
            )}
            {showCorrectAnswer && selectedAnswer && (
              <div className="mt-4 text-sm">
                {selectedAnswer === item.choices[item.answer] ? (
                  <div className="text-green-700">
                    <strong>الإجابة المختارة:</strong> {selectedAnswer} ✔️
                  </div>
                ) : (
                  <div className="text-red-700">
                    <strong>الإجابة المختارة:</strong> {selectedAnswer} ❌
                    <div className="mt-2 text-green-700">
                      <strong>الإجابة الصحيحة:</strong> {item.choices[item.answer]} ✔️
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default QuestionCard;

