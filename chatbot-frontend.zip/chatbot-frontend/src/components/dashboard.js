import React, { useState,useEffect } from "react";
import CardsScreen from "./cardsScreen";
import PreTest from "./preTest";
import { useRouter } from "next/navigation";

export default function Dashboard({ handleLogout }) {
  const [showMainScreen, setShowMainScreen] = useState(true);
  const router = useRouter();


  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser && storedUser.pretest_score_before === null) {
      setShowMainScreen(false);
    } else {
      setShowMainScreen(true);
      if (!window.location.pathname.includes("/dashboard")) {
        router.push("/dashboard");
      }
      //setShowMainScreen(false);

    }
  }, []);
  return (
    <div className="flex flex-col items-center bg-gradient-to-r from-[#5899E2] to-white justify-center min-h-screen h-full w-full">
      <div className="flex justify-end w-full p-4">
        <button
          onClick={handleLogout}
          className="px-4 py-2 text-white transition duration-300 bg-gray-700 rounded-md hover:bg-gray-600"
        >
          Logout
        </button>
      </div>
      <div className="flex items-center justify-center flex-grow w-full pb-20">
        {showMainScreen ? (
          <CardsScreen />
        ) : (
          <div>
            <PreTest handleSubmit={() => setShowMainScreen(true)} />
          </div>
        )}
      </div>
    </div>
  );
}