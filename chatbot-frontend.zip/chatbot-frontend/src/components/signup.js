import React, { useState } from "react";
import { HiOutlineMail } from "react-icons/hi";
import { MdPerson } from "react-icons/md";
import { IoEyeOffOutline, IoEyeSharp } from "react-icons/io5"; // Import IoEyeSharp
import Link from "next/link"; // Correct import for Link from next/link
import axios from "axios";

const Signup = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  // const [method, setMethod] = useState(null);
  const [isLoading, setisLoading] = useState(false);
  const [error, setError] = useState({
    isError: false,
    msg: "",
  });
  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  };

  const otp = Math.floor(Math.random() * 9000 + 1000);
  const method = Math.floor(Math.random() * (4 - 1 + 1) + 1)
  const togglePasswordVisibility = () => setShowPassword(!showPassword);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === 'username') setUsername(value);
    if (name === 'email') setEmail(value);
    if (name === 'password') setPassword(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setisLoading(true);
    setError({ isError: false, msg: "" });
    if(email === 'admin@email.com' && password === 'SuperAdminPassword') {
      localStorage.setItem("user", JSON.stringify({ email: "admin@email.com" }));
      localStorage.setItem("time_start", new Date().getTime());
      localStorage.setItem("method", null);
      window.location.replace("/admin");
  }

    try {
      const response = await axios.post('https://backend-chatbot.nousheen-solutions.com/api/register', {
        username,
        email,
        password,
        method
      });
      console.log(response.data);
      localStorage.setItem("otp", response.data.otp);
      alert("لقد تم تسجيلك في النظام بنجاح");
      window.location.replace("/");
    } catch (error) {
      setisLoading(false);
      if (error.response?.status === 400) {
        setError({ isError: true, msg: "البريد الإلكترونى مستخدم بالفعل" });
      } else {
        setError({ isError: true, msg: "!حدث خطأ ما" });
      }
      console.error('Signup failed:', error);
    }
  };

  return (
    <div className="flex justify-center items-center h-full gap-x-10 min-h-screen bg-gray-100 p-4">
      <div className="max-w-sm w-full">
        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-y-8 bg-opacity-85 bg-white px-6 pt-6 pb-10 shadow-[0_2px_16px_-3px_rgba(173, 216, 230, 0.3)] text-right"
          dir="rtl"
        >
          {/* Header */}
          <div className="text-center">
            <h3 className="text-gray-800 text-3xl font-extrabold">إنشاء حساب مستخدم جديد</h3>
          </div>
          <div className="flex flex-col gap-4">
            {/* Name Input */}
            <div className="relative flex items-center">
              <MdPerson />
               {/* <input type="hidden" name="method" value={method} /> */}
              <input
                name="username"
                type="text"
                value={username}
                onChange={handleInputChange}
                required
                className="bg-transparent w-full text-sm text-gray-800 border-b border-gray-400 focus:border-gray-800 px-2 py-3 outline-none placeholder:text-gray-800"
                placeholder="ادخل الاسم"
              />
            </div>

            {/* Email Input */}
            <div className="relative flex items-center">
              <HiOutlineMail />
              <input
                name="email"
                type="email"
                value={email}
                onChange={handleInputChange}
                required
                className="bg-transparent w-full text-sm text-gray-800 border-b border-gray-400 focus:border-gray-800 px-2 py-3 outline-none placeholder:text-gray-800"
                placeholder="ادخل البريد الإلكتروني"
              />
            </div>

            {/* Password Input */}
            <div className="flex items-center ">
              <input
                name="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={handleInputChange}
                required
                className="bg-transparent w-full text-sm text-gray-800 border-b border-gray-400 focus:border-gray-800 px-2 py-3 outline-none placeholder:text-gray-800"
                placeholder="ادخل كلمة المرور"
              />
            
            </div>
          </div>

          <div className="flex flex-col space-y-8">
            <button
              type="submit"
              className="w-full py-2.5 px-4 text-sm font-semibold tracking-wider rounded-full text-white bg-gray-800 transform transition duration-300 scale-90 hover:scale-100 focus:outline-none"
            >
              تسجيل
            </button>
            <p className="text-gray-800 text-sm ">
              لديك حساب بالفعل؟
              <Link
                href="/"
                className="text-pepsi-blue font-semibold hover:underline ml-1"
              >
                قم بتسجيل الدخول هنا
              </Link>
            </p>
          </div>
          {error.isError && (
          <div className="p-2 flex justify-center mb-4 text-red-500 border border-red-500 rounded">
            {error.msg}
          </div>
        )}
        </form>
      </div>
      <div className='bg-pepsi-blue bg-[url("/looper.svg")] bg-no-repeat bg-contain bg-left rotate-180 max-w-md w-full h-[440px]'></div>
    </div>
  );
};

export default Signup;