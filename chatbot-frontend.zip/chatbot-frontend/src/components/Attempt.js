import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { SmartToy } from "@mui/icons-material";
import { CircularProgress } from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import { ch1, ch2, ch3, ch4, ch5, ch6, pretestQuestions } from "../../data/CourseData";
import { useRouter } from "next/router";
import { formatChapter } from "../../utils/functions";
import { LuClock4 } from "react-icons/lu";
import { Navigation } from "../../components/navigation";
import QuestionCard from "../../components/questionCard";
import { ProgressCircle } from "../../components/progressCircle";

const Attempt = () => {
  const allChapters = [1, 2, 3, 4, 5, 6];
  const router = useRouter();
  const [method, setMethod] = useState(null);
  const messagesEndRef = useRef();
  const [user, setUser] = useState(null);
  const [finishedQCounter, setFinishedQCounter] = useState(0);
  const [messages, setMessages] = useState([]);
  const [pretest, setPretest] = useState(false);
  const [activeQuestion, setActiveQuestion] = useState(0);
  const [activeChapter, setActiveChapter] = useState();
  const [allQuestions, setAllQuestions] = useState([]);
  const [userChapters, setUserChapters] = useState([]);
  const [showTakeToPostTest, setShowTakeToPostTest] = useState(false);
  const [numberOfAttemptedQuestions, setNumberOfAttemptedQuestions] = useState(0);
  const [checkedChapter, setCheckedChapter] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [numberOfErrors, setNumberOfErrors] = useState(0);
  const [numberOfQuestions, setNumberOfQuestions] = useState(1);
  const [difficultyTimer, setDifficultyTimer] = useState(new Date().getTime());
  const [errorsPerDifficulty, setErrorsPerDifficulty] = useState(0);
  const [startTime, setStartTime] = useState(new Date().getTime());
  const [currentDifficulty, setCurrentDifficulty] = useState("");
  const [easyDifficulty, setEasyDifficulty] = useState({
    time: 0,
    errors: 0,
    tasks: 0,
  });
  const [mediumDifficulty, setMediumDifficulty] = useState({
    time: 0,
    errors: 0,
    tasks: 0,
  });
  const [hardDifficulty, setHardDifficulty] = useState({
    time: 0,
    errors: 0,
    tasks: 0,
  });
  const [error, setError] = useState({
    isError: false,
    msg: "",
  });
  const [showChapterSelection, setShowChapterSelection] = useState(false);
  const [timeLeft, setTimeLeft] = useState(200);
  const [answers, setAnswers] = useState([]);
  const [score, setScore] = useState(0);
  const [completeTest, setCompleteTest] = useState(false);
  const [weakChapters, setWeakChapters] = useState([]); // Define weakChapters state
  const [loading, setLoading] = useState(true); // Define loading state

  let user_chapters = [];
  let weak_chapters = [];

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("user");
      const parsedUser = storedUser ? JSON.parse(storedUser) : null;
      console.log("Parsed User:", parsedUser); // Log parsed user
      setUser(parsedUser);
      const storedFinishedQCounter = localStorage.getItem("finishedQCounter");
      setFinishedQCounter(storedFinishedQCounter ? +storedFinishedQCounter : 0);
    }
  }, []);

  useEffect(() => {
    if (user) {
      console.log("User2:", user); // Log user when it changes
    }
  }, [user]);

  useEffect(() => {
    if (router.query.method) {
      console.log("Method from URL2:", router.query.method); // Log method from URL
      setMethod(router.query.method);
    }
  }, [router.query]);

  try {
    if (user && typeof user === "object") {
      user_chapters = user.user_chapters || [];
      weak_chapters = user.weak_chapters || [];
    }
  } catch (error) {
    console.error("Error parsing user data:", error);
  }

  useEffect(() => {
    if (method && userChapters.length === 0) {
      console.log("Setting user chapters based on method:", method);
      switch (parseInt(method)) {
        case 1:
          setUserChapters([1, 2, 3, 4, 5, 6]);
          break;
        case 2:
          setUserChapters(user_chapters);
          break;
        case 3:
          setUserChapters(weak_chapters);
          break;
        case 4:
          setUserChapters([...weak_chapters, ...user_chapters].sort());
          break;
        default:
          setUserChapters([]);
          break;
      }
    }
  }, [method, userChapters.length]);

  useEffect(() => {
    localStorage.setItem("userChapters", JSON.stringify(userChapters));
    if (allQuestions.length === 0) {
      userChapters.forEach((value) => {
        console.log("Value:", value);
        if (value === 1) setAllQuestions((state) => [...state, ...ch1]);
        if (value === 2) setAllQuestions((state) => [...state, ...ch2]);
        if (value === 3) setAllQuestions((state) => [...state, ...ch3]);
        if (value === 4) setAllQuestions((state) => [...state, ...ch4]);
        if (value === 5) setAllQuestions((state) => [...state, ...ch5]);
        if (value === 6) setAllQuestions((state) => [...state, ...ch6]);
      });
      
    }
    console.log("qs:", allQuestions);
  }, [userChapters]);

  useEffect(() => {
    if (timeLeft <= 0) return;
    const timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft]);

  useEffect(() => {
    if (allQuestions.length > 0 && !pretest) {
      setMessages((state) => [...state, allQuestions[activeQuestion]]);
      setStartTime(new Date().getTime());
      setActiveChapter(allQuestions[activeQuestion].ch);
      setAnswers(Array(allQuestions.length).fill(null)); // Initialize answers state
      setLoading(false); // Set loading to false after all operations are done
    }
  }, [allQuestions]);

  const handleAnswer = (choice) => {
    setNumberOfQuestions((state) => state + 1);
    setNumberOfAttemptedQuestions((state) => state + 1);

    const qChapter = allQuestions[activeQuestion].ch;
    if (allQuestions[activeQuestion].answer === +choice) {
      setScore((state) => state + 1);
    } else {
      setNumberOfErrors((state) => state + 1);
      if (!weakChapters.includes(qChapter)) {
        setWeakChapters((state) => [...state, qChapter].sort());
      }
    }

    const updatedAnswers = [...answers];
    updatedAnswers[activeQuestion] = choice;
    setAnswers(updatedAnswers);

    if (activeQuestion < allQuestions.length - 1) {
      setActiveQuestion((prev) => prev + 1);
      setMessages((state) => [...state, allQuestions[activeQuestion + 1]]);
    } else {
      setCompleteTest(true);
    }
  };

  const handleNavigate = (index) => {
    if (index >= 0 && index < allQuestions.length && timeLeft > 0) {
      setActiveQuestion(index);
    }
  };

  const submitLearning = async () => {
    if (typeof window !== "undefined") {
      const user = JSON.parse(localStorage.getItem("user"));

      try {
        const time_taken = (new Date().getTime() - startTime) / 1000;
        const response = await axios.post("https://backend-chatbot.nousheen-solutions.com/api/attempt", {
          email: user.email,
          username: user.username,
          method,
          time_taken,
          chapters: userChapters,
          number_of_errors: numberOfErrors,
          number_of_questions: numberOfQuestions,
          number_of_attempted_questions: numberOfAttemptedQuestions,
        });

        localStorage.setItem("attempt_pk", response.data.pk_datetime);
        localStorage.setItem("post_test", JSON.stringify(true));
        localStorage.setItem("method", method);

        user.method = method;
        localStorage.setItem("user", JSON.stringify(user));

        router.replace("/post_test");
      } catch (err) {
        setError({ isError: true, msg: "حدث خطأ ما!" });
        console.error("Submission failed:", err);
      }
    }
  };

  const handleLogout = async () => {
    if (typeof window !== "undefined") {
      const finishedQCounter = localStorage.getItem("finishedQCounter");
      const user = JSON.parse(localStorage.getItem("user"));

      if (finishedQCounter) {
        if (!isLoading) {
          setIsLoading(true);
          try {
            await axios.put("https://backend-chatbot.nousheen-solutions.com/api/update", {
              email: user.email,
              username: user.username,
              method,
              password: user.password,
            });
            localStorage.clear();
            router.replace("/");
            setIsLoading(false);
          } catch (err) {
            setIsLoading(false);
            setError({ isError: true, msg: "حدث خطأ ما!" });
            console.error("Logout failed:", err);
          }
        }
      } else {
        localStorage.clear();
        router.replace("/");
      }
    }
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };
console.log("allqs",allQuestions);
  if (loading) return <div>Loading...</div>; // Show loading indicator while loading

  return (
    <div className='flex flex-col justify-between max-w-2xl w-[800px] p-6 space-y-4 shadow-lg bg-white bg-[url("/looper.svg")] bg-left h-[400px] rounded-lg'>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-x-1">
          <LuClock4 className="text-2xl leading-none" />
          <div className="flex flex-col font-semibold">
            <span className="text-gray-500 text-[10px] pt-1 leading-[9px] ">
              Remaining Time
            </span>
            <span className="text-sm leading-5 font-bold">
              {formatTime(timeLeft)}
            </span>
          </div>
        </div>
         
          <button
            onClick={submitLearning}
            disabled={timeLeft <= 0}
            className="bg-gradient-to-r from-[#5899E2] to-pepsi-blue duration-300 transition-colors hover:from-pepsi-blue hover:to-[#5899E2] cursor-pointer text-white px-4 py-2 text-sm rounded-md font-bold"
          >
            Submit Test
          </button>
        
      </div>

      <div className="flex items-center gap-4">
        <ProgressCircle
          currentIndex={answers.filter((answer) => answer !== null).length}
          totalQuestions={allQuestions.length}
        />

        <QuestionCard
          questions={[allQuestions[activeQuestion]]}
          selectedAnswer={answers[activeQuestion]}
          handleAnswer={handleAnswer}
          showExplanation={true} // Show explanation after selecting an answer
          showCorrectAnswer={true} // Show correct answer after selecting an answer
        />
      </div>
      <div>
        <Navigation
          totalQuestions={allQuestions.length}
          currentIndex={activeQuestion}
          answeredQuestions={answers.map((answer) => answer !== null)}
          onNavigate={handleNavigate}
        />
      </div>
    </div>
  );
};

export default Attempt;