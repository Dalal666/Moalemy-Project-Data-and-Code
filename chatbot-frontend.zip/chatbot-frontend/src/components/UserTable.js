"use client"; // Required for Next.js App Router

import React, { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import * as XLSX from "xlsx";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { ModuleRegistry } from "ag-grid-community";
import {
  ClientSideRowModelModule,
  CellStyleModule,
  TextFilterModule,
  NumberFilterModule,
  ValidationModule,
} from "ag-grid-community";
import Sidebar from "./sidebar";

// Register the required modules
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  CellStyleModule,
  TextFilterModule,
  NumberFilterModule,
  ValidationModule,
]);

// Correct import of AgGridReact
const AgGridReact = dynamic(
  () => import("ag-grid-react").then((module) => module.AgGridReact),
  { ssr: false }
);

export default function UserTable() {
  const [userData, setUserData] = useState([]);
  const router = useRouter();

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch("https://backend-chatbot.nousheen-solutions.com/api/attempts"); // Replace with your API endpoint
      const data = await response.json();
      setUserData(formatUserData(data)); // Format the data for the grid
    };

    fetchData();
  }, []);

  const formatUserData = (data) => {
    return data
      .map((user) => ({
        username: user.username,
        email: user.email,
        preTest: user.pretest_score_before,
        learningMethod:
          user.method === 1
            ? "Static"
            : user.method === 2
            ? "Adaptable"
            : user.method === 3
            ? "Adaptive"
            : "Mixed",
        postTest: user.test_score,
        learningGain: user.test_score - user.pretest_score_before,
        rlg: Math.round(
          ((user.test_score - user.pretest_score_before) /
            (10 - user.pretest_score_before)) *
            100
        ),
        noMesg: user.number_of_questions * 2,
        totalTime:
          user.time_taken_hard + user.time_taken_easy + user.time_taken_medium,
        totalTasks: user.number_of_attempted_questions,
        easyTime: user.time_taken_easy,
        easyErrors: user.errors_easy,
        easyTasks: user.tasks_easy,
        mediumTime: user.time_taken_medium,
        mediumErrors: user.errors_medium,
        mediumTasks: user.tasks_medium,
        hardTime: user.time_taken_hard,
        hardErrors: user.errors_hard,
        hardTasks: user.tasks_hard,
      }))
      .filter((user) => Object.values(user).every((value) => value !== null));
  };

  const columnDefs = [
    { headerName: "Username", field: "username", rowGroup: false },
    { headerName: "Pre-Test", field: "preTest" },
    { headerName: "Learning Method", field: "learningMethod" },
    { headerName: "Post-Test", field: "postTest" },
    { headerName: "Learning Gain", field: "learningGain" },
    { headerName: "RLG", field: "rlg" },
    { headerName: "No. Msg", field: "noMesg" },
    { headerName: "Total Time", field: "totalTime" },
    { headerName: "Total Tasks", field: "totalTasks" },
    {
      headerName: "Task Details",
      children: [
        {
          headerName: "Easy",
          children: [
            { headerName: "Time", field: "easyTime", type: "numberColumn" },
            { headerName: "Errors", field: "easyErrors", type: "numberColumn" },
            { headerName: "Tasks", field: "easyTasks", type: "numberColumn" },
          ],
        },
        {
          headerName: "Medium",
          children: [
            { headerName: "Time", field: "mediumTime", type: "numberColumn" },
            {
              headerName: "Errors",
              field: "mediumErrors",
              type: "numberColumn",
            },
            { headerName: "Tasks", field: "mediumTasks", type: "numberColumn" },
          ],
        },
        {
          headerName: "Hard",
          children: [
            { headerName: "Time", field: "hardTime", type: "numberColumn" },
            { headerName: "Errors", field: "hardErrors", type: "numberColumn" },
            { headerName: "Tasks", field: "hardTasks", type: "numberColumn" },
          ],
        },
      ],
    },
  ];

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(userData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Data");
    XLSX.writeFile(workbook, "AdminDashboardData.xlsx");
  };

  const handleRowClick = (event) => {
    const email = event.data.email;
    router.push(`/userAttempt/${email}`);
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-gray-800 text-white h-screen">
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex flex-col flex-1 p-6 bg-gray-100">
        {/* Export Button */}
        <div className="flex justify-end mb-4">
          <button
            onClick={exportToExcel}
            className="bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-700 hover:to-blue-500 text-white px-4 py-2 text-sm rounded-md font-bold"
          >
            Export to Excel
          </button>
        </div>

        {/* Table Container */}
        <div
          className="ag-theme-alpine"
          style={{ height: "calc(100vh - 100px)", width: "100%" }}
        >
          <AgGridReact
            rowData={userData}
            columnDefs={columnDefs}
            modules={[ClientSideRowModelModule, ValidationModule]}
            defaultColDef={{
              flex: 1,
              minWidth: 100,
              resizable: true,
              filter: true,
              sortable: true,
            }}
            pagination={true}
            paginationPageSize={10}
            onRowClicked={handleRowClick}
          />
        </div>
      </div>
    </div>
  );
}
