'use client';

import React from 'react';
import { Step } from 'nextstepjs';
import { X } from 'lucide-react';


const CustomCard = ({
  step,
  currentStep,
  totalSteps,
  nextStep,
  prevStep,
  skipTour,
  arrow,
}) => {
  return (
    <div className="bg-pepsi-blue text-white rounded-lg shadow-lg p-6 max-w-md">
      <div className='flex justify-end w-full'>
        <X onClick={skipTour} className='cursor-pointer' />
      </div>
      <div className="flex items-center gap-3 mb-4">
        {step.icon && <div className="text-2xl">{step.icon}</div>}
        <h3 className="text-xl font-bold">{step.title}</h3>
      </div>
      
      <div className="mb-6">{step.content}</div>
      
      {arrow}
      
      <div className="flex justify-between items-center">
        <div className="text-sm">
          Step {currentStep + 1} of {totalSteps}
        </div>
      </div>
    </div>
  );
};

export default CustomCard;