import Link from "next/link";
import { useRouter } from 'next/router';

const Sidebar = () => {
  const router = useRouter(); // Use the useRouter hook to get the router object

  const handleLogout = () => {
    localStorage.removeItem("user");
    router.replace("/");
  };

  return (
    <div className="h-screen w-64 bg-gray-800 text-white fixed">
      <div className="p-5 text-2xl font-bold">Admin Dashboard</div>
      <ul className="mt-6">
        <li className="p-4 hover:bg-gray-700">
          <Link href="/admin">Users</Link>
        </li>
        <li className="p-4 hover:bg-gray-700">
          <Link href="/satisfaction">Satisfaction</Link>
        </li>
        <li className="list-none">
          <button onClick={handleLogout} className="bg-gray-700 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition duration-300">
            Logout
          </button>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;