import CustomCard from "@/components/CustomCard";
import "@/styles/globals.css";
import { NextStepProvider, NextStep } from "nextstepjs";

const steps = [
  {
    tour: "mainTour",
    steps: [
      {
        title: "Pre-test",
        content: "يبدأ الآن اختبار تحديد مستوى معرفتك قبل مرحلة التعلم.",
        selector: "body",
        showControls: true,
        showSkip: true,
      },
    ],
  },
  {
    tour: "postTestTour",
    steps: [
      {
        title: "Post-test",
        content: "يبدأ الآن اختبار تحديد مستوى معرفتك بعد مرحلة التعلم.",
        selector: "body",
        showControls: true,
        showSkip: true,
      },
    ],
  },
  {
    tour: "surveyTour",
    steps: [
      {
        title: "Survey",
        content: "يبدأ الآن استبيان قياس فعالية النظام من وجهة نظرك.",
        selector: "body",
        showControls: true,
        showSkip: true,
      },
    ],
  },
  {
    tour: "learnTour",
    steps: [
      {
        title: "Learn",
        content:
          "هذه هي مرحلة التعلم حيث ستتمكن من استكشاف المواد التعليمية وتعزيز معرفتك.",
        selector: "body",
        showControls: true,
        showSkip: true,
      },
    ],
  },
];

export default function App({ Component, pageProps }) {
  return (
    <NextStepProvider>
      <NextStep steps={steps} cardComponent={CustomCard}>
        <Component {...pageProps} />
      </NextStep>
    </NextStepProvider>
  );
}
