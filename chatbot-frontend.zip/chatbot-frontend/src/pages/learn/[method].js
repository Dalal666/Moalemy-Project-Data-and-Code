import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { SmartToy } from "@mui/icons-material";
import { CircularProgress } from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import {
  ch1,
  ch2,
  ch3,
  ch4,
  ch5,
  ch6,
  pretestQuestions,
} from "../../data/CourseData";
import { useRouter } from "next/router";
import { formatChapter } from "../../utils/functions";
import { LuClock4 } from "react-icons/lu";
import { Navigation } from "../../components/navigation";
import QuestionCard from "../../components/questoncardLearning.js";
import { ProgressCircle } from "../../components/progressCircle";
import { useNextStep } from "nextstepjs";

import Link from "next/link";
const Attempt = () => {
  const allChapters = [1, 2, 3, 4, 5, 6];
  const router = useRouter();
  const [isWeakChaptersCompleted, setIsWeakChaptersCompleted] = useState(false);
  const [selectedChapters, setSelectedChapters] = useState([]);
  const [isSecondLearningSession, setIsSecondLearningSession] = useState(false);
  const [firstPhaseChapters, setFirstPhaseChapters] = useState([]);
  const [method, setMethod] = useState(null);
  const messagesEndRef = useRef();
  const [user, setUser] = useState(null);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [finishedQCounter, setFinishedQCounter] = useState(0);
  const [messages, setMessages] = useState([]);
  const [pretest, setPretest] = useState(false);
  const [activeQuestion, setActiveQuestion] = useState(0);
  const [activeChapter, setActiveChapter] = useState();
  const [allQuestions, setAllQuestions] = useState([]);
  const [userChapters, setUserChapters] = useState([]);
  const [showTakeToPostTest, setShowTakeToPostTest] = useState(false);
  const [numberOfAttemptedQuestions, setNumberOfAttemptedQuestions] =
    useState(0);
  const [checkedChapter, setCheckedChapter] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [numberOfErrors, setNumberOfErrors] = useState(0);
  const [numberOfQuestions, setNumberOfQuestions] = useState(0);
  const [difficultyTimer, setDifficultyTimer] = useState(new Date().getTime());
  const [errorsPerDifficulty, setErrorsPerDifficulty] = useState(0);
  const [startTime, setStartTime] = useState(new Date().getTime());
  const [currentDifficulty, setCurrentDifficulty] = useState("");
  const [skipped, setSkipped] = useState(false);
  const [easyDifficulty, setEasyDifficulty] = useState({
    time: 0,
    errors: 0,
    tasks: 0,
  });
  const [mediumDifficulty, setMediumDifficulty] = useState({
    time: 0,
    errors: 0,
    tasks: 0,
  });
  const [hardDifficulty, setHardDifficulty] = useState({
    time: 0,
    errors: 0,
    tasks: 0,
  });
  const [error, setError] = useState({
    isError: false,
    msg: "",
  });
  const [firstPhaseResults, setFirstPhaseResults] = useState({
    answers: [],
    numberOfErrors: 0,
    numberOfQuestions: 0,
    numberOfAttemptedQuestions: 0,
    easyDifficulty: { time: 0, errors: 0, tasks: 0 },
    mediumDifficulty: { time: 0, errors: 0, tasks: 0 },
    hardDifficulty: { time: 0, errors: 0, tasks: 0 },
  });

  const [showChapterSelection, setShowChapterSelection] = useState(false);
  const [timeLeft, setTimeLeft] = useState(200);
  const [answers, setAnswers] = useState([]);
  const [score, setScore] = useState(0);
  const [completeTest, setCompleteTest] = useState(false);
  const [weakChapters, setWeakChapters] = useState([]); // Define weakChapters state
  const [loading, setLoading] = useState(true); // Define loading state
  const [showNextQuestion, setShowNextQuestion] = useState(false); // Define showNextQuestion state
  const { startNextStep, closeNextStep, currentTour } = useNextStep();

  useEffect(() => {
    startNextStep("learnTour");
  }, [startNextStep]);

  let user_chapters = [];
  let weak_chapters = [];
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        router.replace("/"); // Redirect to home page if storedUser is not defined
      } else {
        const parsedUser = JSON.parse(storedUser);
        console.log("Parsed User:", parsedUser); // Log parsed user
        setUser(parsedUser);
        const storedFinishedQCounter = localStorage.getItem("finishedQCounter");
        setFinishedQCounter(
          storedFinishedQCounter ? +storedFinishedQCounter : 0
        );
        setLoading(false);
      }
    }
  }, [router]);
  useEffect(() => {
    if (method === "4" && weakChapters.length > 0 && !isWeakChaptersCompleted) {
      setUserChapters(weakChapters); // Start with weak chapters
    }
  }, [method, weakChapters, isWeakChaptersCompleted]);

  useEffect(() => {
    // Apply overflow hidden to html and body to prevent scrolling
    document.documentElement.style.overflow = "hidden";
    document.body.style.overflow = "hidden";

    // Cleanup function to reset overflow when component unmounts
    return () => {
      document.documentElement.style.overflow = "";
      document.body.style.overflow = "";
    };
  }, []);
  useEffect(() => {
    if (user) {
      console.log("User2:", user); // Log user when it changes
    }
  }, [user]);

  useEffect(() => {
    if (router.query.method) {
      console.log("Method from URL2:", router.query.method); // Log method from URL
      setMethod(router.query.method);
    }
  }, [router.query]);

  try {
    if (user && typeof user === "object") {
      user_chapters = user.user_chapters || [];
      console.log("User Chapters:", user_chapters);
      weak_chapters = user.weak_chapters || [];
    }
  } catch (error) {
    console.error("Error parsing user data:", error);
  }

  useEffect(() => {
    if (method && userChapters.length === 0) {
      console.log("Setting user chapters based on method:", method);
      switch (parseInt(method)) {
        case 1:
          setUserChapters([1, 2, 3, 4, 5, 6]);
          break;
        case 2:
          setUserChapters(user_chapters);
          break;
        case 3:
          setUserChapters(weak_chapters);
          break;
        case 4:
          setUserChapters([...weak_chapters, ...user_chapters].sort());
          break;
        default:
          setUserChapters([]);
          break;
      }
    }
  }, [method, userChapters.length]);

  useEffect(() => {
    localStorage.setItem("userChapters", JSON.stringify(userChapters));
    if (allQuestions.length === 0) {
      userChapters.forEach((value) => {
        console.log("Value:", value);
        if (value === 1) setAllQuestions((state) => [...state, ...ch1]);
        if (value === 2) setAllQuestions((state) => [...state, ...ch2]);
        if (value === 3) setAllQuestions((state) => [...state, ...ch3]);
        if (value === 4) setAllQuestions((state) => [...state, ...ch4]);
        if (value === 5) setAllQuestions((state) => [...state, ...ch5]);
        if (value === 6) setAllQuestions((state) => [...state, ...ch6]);
      });
    }
    console.log("qs:", allQuestions);
  }, [userChapters]);

  useEffect(() => {
    if (allQuestions.length > 0 && !pretest) {
      setMessages((state) => [...state, allQuestions[activeQuestion]]);
      setStartTime(new Date().getTime());
      setActiveChapter(allQuestions[activeQuestion].ch);
      setAnswers(Array(allQuestions.length).fill(null)); // Initialize answers state
      setLoading(false); // Set loading to false after all operations are done
    }
  }, [allQuestions]);

  const checkWeakChaptersCompletion = () => {
    // Check if all questions have either been answered or skipped
    const allQuestionsAttempted = answers.every((answer) => answer !== null);

    if (allQuestionsAttempted && method === "4" && !isWeakChaptersCompleted) {
      handleWeakChaptersCompletion();
    }
  };

  useEffect(() => {
    if (method === "4" && answers.length > 0) {
      checkWeakChaptersCompletion();
    }
  }, [answers, method]);
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-16 h-16 border-t-4 border-b-4 border-blue-500 rounded-full animate-spin"></div>
      </div>
    );
  }
  const handleWeakChaptersCompletion = () => {
    setFirstPhaseChapters([...userChapters]);
    setFirstPhaseResults({
      answers: [...answers],
      numberOfErrors,
      numberOfQuestions,
      numberOfAttemptedQuestions,
      easyDifficulty: { ...easyDifficulty },
      mediumDifficulty: { ...mediumDifficulty },
      hardDifficulty: { ...hardDifficulty },
    });
    setIsWeakChaptersCompleted(true);
    setShowChapterSelection(true);
    setAnswers([]);
    setActiveQuestion(0);
    setNumberOfAttemptedQuestions(0);
    setNumberOfErrors(0);
    setScore(0);
    setEasyDifficulty({ time: 0, errors: 0, tasks: 0 });
    setMediumDifficulty({ time: 0, errors: 0, tasks: 0 });
    setHardDifficulty({ time: 0, errors: 0, tasks: 0 });
    setIsWeakChaptersCompleted(true);
    setShowChapterSelection(true);
    // Reset answers and other relevant states for the second phase
    // setAnswers([]);
    // setActiveQuestion(0);
    // setNumberOfAttemptedQuestions(0);
    // setNumberOfErrors(0);
    // setScore(0);
  };

  const handleChapterSelection = (chapter) => {
    setSelectedChapters((prev) =>
      prev.includes(chapter)
        ? prev.filter((ch) => ch !== chapter)
        : [...prev, chapter]
    );
  };

  // const startSecondLearningSession = () => {
  //   if (selectedChapters.length === 0) {
  //     // Show error or notification that at least one chapter must be selected
  //     return;
  //   }

  //   const newQuestions = [];
  //   selectedChapters.forEach((chapter) => {
  //     if (chapter === 1) newQuestions.push(...ch1);
  //     if (chapter === 2) newQuestions.push(...ch2);
  //     if (chapter === 3) newQuestions.push(...ch3);
  //     if (chapter === 4) newQuestions.push(...ch4);
  //     if (chapter === 5) newQuestions.push(...ch5);
  //     if (chapter === 6) newQuestions.push(...ch6);
  //   });
  //   setAllQuestions(newQuestions);
  //   setIsSecondLearningSession(true);
  //   setShowChapterSelection(false);
  //   setAnswers(Array(newQuestions.length).fill(null));
  //   setActiveQuestion(0);
  // };

  const startSecondLearningSession = () => {
    if (selectedChapters.length === 0) {
      return;
    }

    const newQuestions = [];
    selectedChapters.forEach((chapter) => {
      if (chapter === 1) newQuestions.push(...ch1);
      if (chapter === 2) newQuestions.push(...ch2);
      if (chapter === 3) newQuestions.push(...ch3);
      if (chapter === 4) newQuestions.push(...ch4);
      if (chapter === 5) newQuestions.push(...ch5);
      if (chapter === 6) newQuestions.push(...ch6);
    });

    // Reset all relevant state for the second phase
    setAllQuestions(newQuestions);
    setIsSecondLearningSession(true);
    setShowChapterSelection(false);
    setAnswers(Array(newQuestions.length).fill(null));
    setActiveQuestion(0);
    setShowNextQuestion(false); // Reset the explanation visibility
    setSkipped(false); // Reset the skipped state
    setMessages([]); // Clear any existing messages
    setStartTime(new Date().getTime()); // Reset the start time

    // Add the first question to messages after a brief delay
    setTimeout(() => {
      setMessages([newQuestions[0]]);
    }, 0);
  };

  const handleAnswer = (choice) => {
    setNumberOfQuestions((state) => state + 1);
    setNumberOfAttemptedQuestions((state) => state + 1);

    const qChapter = allQuestions[activeQuestion].ch;
    const qDifficulty = allQuestions[activeQuestion].difficulty;
    console.log("answer", allQuestions[activeQuestion].answer);
    console.log("choice", choice);
    console.log("Question Difficulty:", qDifficulty);
    console.log("Question Difficulty:", currentDifficulty);

    if (qDifficulty) {
      console.log("timer set!");
      setDifficultyTimer(new Date().getTime());
      let easyTimer = 0;
      let mediumTimer = 0;
      let hardTimer = 0;
      switch (qDifficulty) {
        case "سهل":
          easyTimer = (new Date().getTime() - difficultyTimer) / 1000;
          setEasyDifficulty((prev) => ({
            ...prev,
            time: prev.time + easyTimer,
            errors:
              allQuestions[activeQuestion].choices[
                allQuestions[activeQuestion].answer
              ] !== choice
                ? prev.errors + 1
                : prev.errors,
            tasks: prev.tasks + 1,
          }));
          break;
        case "متوسط":
          mediumTimer = (new Date().getTime() - difficultyTimer) / 1000;
          setMediumDifficulty((prev) => ({
            ...prev,
            time: prev.time + mediumTimer,
            errors:
              allQuestions[activeQuestion].choices[
                allQuestions[activeQuestion].answer
              ] !== choice
                ? prev.errors + 1
                : prev.errors,
            tasks: prev.tasks + 1,
          }));
          break;
        case "صعب":
          hardTimer = (new Date().getTime() - difficultyTimer) / 1000;
          setHardDifficulty((prev) => ({
            ...prev,
            time: prev.time + hardTimer,
            errors:
              allQuestions[activeQuestion].choices[
                allQuestions[activeQuestion].answer
              ] !== choice
                ? prev.errors + 1
                : prev.errors,
            tasks: prev.tasks + 1,
          }));
          break;
        default:
          break;
      }
      setCurrentDifficulty(qDifficulty);
    }

    if (
      allQuestions[activeQuestion].choices[
        allQuestions[activeQuestion].answer
      ] === choice
    ) {
      console.log("anwere corretly", score);
      setScore((state) => state + 1);
    } else {
      setNumberOfErrors((state) => state + 1);
      console.log("incorretly answered ", numberOfErrors);
      if (!weakChapters.includes(qChapter)) {
        setWeakChapters((state) => [...state, qChapter].sort());
      }
    }

    console.log("answer", allQuestions[activeQuestion].answer);
    console.log("choice", choice);

    const updatedAnswers = [...answers];
    updatedAnswers[activeQuestion] = choice;
    setAnswers(updatedAnswers);

    setShowNextQuestion(true); // Set showNextQuestion to true to show explanation and correct answer
  };

  const handleNextQuestion = (index) => {
    if (index >= 0 && index < allQuestions.length && timeLeft > 0) {
      setActiveQuestion(index);
    }
    if (activeQuestion < allQuestions.length - 1) {
      // setActiveQuestion((prev) => prev + 1);
      setMessages((state) => [...state, allQuestions[activeQuestion + 1]]);
    } else {
      setCompleteTest(true);
    }
    setShowNextQuestion(false);
    setSkipped(false); // Reset showNextQuestion to false for the next question
  };
  const handleSkip = () => {
    const qDifficulty = allQuestions[activeQuestion].difficulty;

    if (qDifficulty) {
      console.log("timer set!");
      setDifficultyTimer(new Date().getTime());
      let easyTimer = 0;
      let mediumTimer = 0;
      let hardTimer = 0;
      switch (qDifficulty) {
        case "سهل":
          easyTimer = (new Date().getTime() - difficultyTimer) / 1000;
          setEasyDifficulty((prev) => ({
            ...prev,
            time: prev.time + easyTimer,
          }));
          break;
        case "متوسط":
          mediumTimer = (new Date().getTime() - difficultyTimer) / 1000;
          setMediumDifficulty((prev) => ({
            ...prev,
            time: prev.time + mediumTimer,
          }));
          break;
        case "صعب":
          hardTimer = (new Date().getTime() - difficultyTimer) / 1000;
          setHardDifficulty((prev) => ({
            ...prev,
            time: prev.time + hardTimer,
          }));
          break;
        default:
          break;
      }
    }
    setSkipped(true);
    setNumberOfQuestions((state) => state + 1);
    const updatedAnswers = [...answers];
    updatedAnswers[activeQuestion] = "skipped"; // Use "skipped" as a marker for skipped questions
    setAnswers(updatedAnswers);
    // setTimeout(() => {
    //   handleNextQuestion(activeQuestion + 1); // Move to the next question after 6 seconds
    // }, 3000);
    setShowNextQuestion(true);
  };
  const handleNavigate = (index) => {
    if (index >= 0 && index < allQuestions.length && timeLeft > 0) {
      setActiveQuestion(index);
    }
  };

  const submitLearning = async () => {
    if (typeof window !== "undefined") {
      const user = JSON.parse(localStorage.getItem("user"));

      try {
        const time_taken = (new Date().getTime() - startTime) / 1000;
        const chaptersToSubmit =
          method === "4"
            ? [...new Set([...firstPhaseChapters, ...selectedChapters])].sort(
                (a, b) => a - b
              )
            : userChapters;
        const combinedResults =
          method === "4"
            ? {
                number_of_errors:
                  numberOfErrors + firstPhaseResults.numberOfErrors,
                number_of_questions:
                  allQuestions.length + firstPhaseResults.numberOfQuestions,
                number_of_attempted_questions:
                  numberOfAttemptedQuestions +
                  firstPhaseResults.numberOfAttemptedQuestions,
                time_taken_easy:
                  easyDifficulty.time + firstPhaseResults.easyDifficulty.time,
                time_taken_medium:
                  mediumDifficulty.time +
                  firstPhaseResults.mediumDifficulty.time,
                time_taken_hard:
                  hardDifficulty.time + firstPhaseResults.hardDifficulty.time,
                errors_easy:
                  easyDifficulty.errors +
                  firstPhaseResults.easyDifficulty.errors,
                errors_medium:
                  mediumDifficulty.errors +
                  firstPhaseResults.mediumDifficulty.errors,
                errors_hard:
                  hardDifficulty.errors +
                  firstPhaseResults.hardDifficulty.errors,
                tasks_easy:
                  easyDifficulty.tasks + firstPhaseResults.easyDifficulty.tasks,
                tasks_medium:
                  mediumDifficulty.tasks +
                  firstPhaseResults.mediumDifficulty.tasks,
                tasks_hard:
                  hardDifficulty.tasks + firstPhaseResults.hardDifficulty.tasks,
              }
            : {
                number_of_errors: numberOfErrors,
                number_of_questions: allQuestions.length,
                number_of_attempted_questions: numberOfAttemptedQuestions,
                time_taken_easy: easyDifficulty.time,
                time_taken_medium: mediumDifficulty.time,
                time_taken_hard: hardDifficulty.time,
                errors_easy: easyDifficulty.errors,
                errors_medium: mediumDifficulty.errors,
                errors_hard: hardDifficulty.errors,
                tasks_easy: easyDifficulty.tasks,
                tasks_medium: mediumDifficulty.tasks,
                tasks_hard: hardDifficulty.tasks,
              };
        const time = parseFloat(timeElapsed);

        console.log(timeElapsed, "time");
        const response = await axios.post("https://backend-chatbot.nousheen-solutions.com/api/attempt", {
          email: user.email,
          username: user.username,
          method,
          time_taken: time,
          chapters: chaptersToSubmit,
          ...combinedResults,
        });
        // const response = await axios.post("https://backend-chatbot.nousheen-solutions.com/api/attempt", {
        //   email: user.email,
        //   username: user.username,
        //   method,
        //   time_taken,
        //   chapters: userChapters,
        //   number_of_errors: numberOfErrors,
        //   number_of_questions: allQuestions.length,
        //   // number_of_questions: numberOfQuestions,
        //   number_of_attempted_questions: numberOfAttemptedQuestions,
        //   time_taken_easy: easyDifficulty.time,
        // time_taken_medium: mediumDifficulty.time,
        // time_taken_hard: hardDifficulty.time,
        // errors_easy: easyDifficulty.errors,
        // errors_medium: mediumDifficulty.errors,
        // errors_hard: hardDifficulty.errors,
        // tasks_easy: easyDifficulty.tasks,
        // tasks_medium: mediumDifficulty.tasks,
        // tasks_hard: hardDifficulty.tasks,
        // });

        localStorage.setItem("attempt_pk", response.data.pk_datetime);
        localStorage.setItem("post_test", JSON.stringify(true));
        localStorage.setItem("method", method);

        user.method = method;
        localStorage.setItem("user", JSON.stringify(user));

        router.replace("/postTest");
      } catch (err) {
        setError({ isError: true, msg: "حدث خطأ ما!" });
        console.error("Submission failed:", err);
      }
    }
  };

  const handleLogout = async () => {
    if (typeof window !== "undefined") {
      const finishedQCounter = localStorage.getItem("finishedQCounter");
      const user = JSON.parse(localStorage.getItem("user"));

      if (finishedQCounter) {
        if (!isLoading) {
          setIsLoading(true);
          try {
            await axios.put("https://backend-chatbot.nousheen-solutions.com/api/update", {
              email: user.email,
              username: user.username,
              method,
              password: user.password,
            });
            localStorage.removeItem("user");
            router.replace("/");
            setIsLoading(false);
          } catch (err) {
            setIsLoading(false);
            setError({ isError: true, msg: "حدث خطأ ما!" });
            console.error("Logout failed:", err);
          }
        }
      } else {
        localStorage.removeItem("user");
        router.replace("/");
      }
    }
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };
  console.log("allqs", allQuestions);
  // Show loading indicator while loading

  // return (

  //   <div className="min-h-screen bg-gradient-to-r from-[#5899E2] to-white flex flex-col items-center justify-center" style={{ overflow: 'hidden' }}>
  //   <div className="flex justify-end w-full p-4">
  //     <li className="list-none">
  //       <button
  //         onClick={handleLogout}
  //         className="px-4 py-2 text-white transition duration-300 bg-gray-700 rounded-md hover:bg-gray-600"
  //       >
  //         Logout
  //       </button>
  //     </li>
  //   </div>
  //   <div className="flex items-center justify-center flex-grow w-full pb-20">
  //  <div className="flex flex-col justify-between max-w-2xl w-full p-6 space-y-4 shadow-lg bg-white bg-[url('/looper.svg')] bg-left min-h-[400px] rounded-lg overflow-auto">
  //     <div className="flex items-center justify-between">
  //       <div className="flex items-center gap-x-1">
  //         <LuClock4 className="text-2xl leading-none" />
  //         <div className="flex flex-col font-semibold">

  //           <span className="text-sm font-bold leading-5">
  //           {formatTime(timeElapsed)}
  //           </span>
  //         </div>
  //       </div>
  //       {/* <button
  //         onClick={submitLearning}
  //         disabled={timeLeft <= 0}
  //         className="bg-gradient-to-r from-[#5899E2] to-pepsi-blue duration-300 transition-colors hover:from-pepsi-blue hover:to-[#5899E2] cursor-pointer text-white px-4 py-2 text-sm rounded-md font-bold"
  //       >
  //         تقديم الاختبار
  //       </button> */}
  //        <button
  //             onClick={submitLearning}
  //             disabled={answers.filter((answer) => answer !== null).length !== allQuestions.length}
  //             className={`bg-gradient-to-r from-[#5899E2] to-pepsi-blue duration-300 transition-colors hover:from-pepsi-blue hover:to-[#5899E2] cursor-pointer text-white px-4 py-2 text-sm rounded-md font-bold ${
  //               answers.filter((answer) => answer !== null).length !== allQuestions.length ? "opacity-50 cursor-not-allowed" : ""
  //             }`}
  //           >
  //             تقديم الاختبار
  //           </button>
  //     </div>

  //     <div className="flex items-center gap-4">
  //       <ProgressCircle
  //         currentIndex={answers.filter((answer) => answer !== null).length}
  //         totalQuestions={allQuestions.length}
  //       />

  // <>
  //   {console.log("allqs entering ", allQuestions[activeQuestion])}
  //   {allQuestions.length > 0 && (
  //     <>
  //       {console.log("allqs entering2 ", allQuestions[activeQuestion])}
  //       <QuestionCard
  //            questions={[allQuestions[activeQuestion]]} // Convert to array
  //            selectedAnswer={answers[activeQuestion]}
  //            handleAnswer={handleAnswer} // Pass handleAnswer function
  //            showExplanation={showNextQuestion}
  //            showCorrectAnswer={showNextQuestion}
  //            skipped={skipped}

  //       />
  //     </>
  //   )}
  // </>

  //     </div>
  //     <div className="flex justify-center">
  //           {!answers[activeQuestion] && (
  //             <button
  //               onClick={handleSkip}
  //               className="bg-gradient-to-r from-[#5899E2] to-pepsi-blue duration-300 transition-colors hover:from-pepsi-blue hover:to-[#5899E2] cursor-pointer text-white px-4 py-2 text-sm rounded-md font-bold w-30"
  //             >
  //               تخطي السؤال
  //             </button>
  //           )}
  //         </div>
  //     <div className="flex justify-between">

  //       <Navigation
  //         totalQuestions={allQuestions.length}
  //         currentIndex={activeQuestion}
  //         answeredQuestions={answers.map((answer) => answer !== null)}
  //         onNavigate={handleNextQuestion}
  //       />
  //     </div>
  //   </div>
  //   </div>
  //   </div>
  // );
  return (
    <div
      className="min-h-screen bg-gradient-to-r from-[#5899E2] to-white flex flex-col items-center justify-center"
      style={{ overflow: "hidden" }}
    >
      <div className="flex justify-end w-full p-4">
        <li className="list-none">
          <button
            onClick={handleLogout}
            className="px-4 py-2 text-white transition duration-300 bg-gray-700 rounded-md hover:bg-gray-600"
          >
            Logout
          </button>
        </li>
      </div>
      <div className="flex items-center justify-center flex-grow w-full pb-20">
        <div className="flex flex-col justify-between max-w-2xl w-full p-6 space-y-4 shadow-lg bg-white bg-[url('/looper.svg')] bg-left min-h-[400px] rounded-lg overflow-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-x-1">
              <LuClock4 className="text-2xl leading-none" />
              <div className="flex flex-col font-semibold">
                <span className="text-sm font-bold leading-5">
                  {formatTime(timeElapsed)}
                </span>
              </div>
            </div>
            <button
              onClick={submitLearning}
              disabled={
                answers.filter((answer) => answer !== null).length !==
                allQuestions.length
              }
              className={`bg-gradient-to-r from-[#5899E2] to-pepsi-blue duration-300 transition-colors hover:from-pepsi-blue hover:to-[#5899E2] cursor-pointer text-white px-4 py-2 text-sm rounded-md font-bold ${
                answers.filter((answer) => answer !== null).length !==
                allQuestions.length
                  ? "opacity-50 cursor-not-allowed"
                  : ""
              }`}
            >
              تقديم الاختبار
            </button>
          </div>

          {method === "4" && !isWeakChaptersCompleted ? (
            <div className="flex flex-col space-y-4">
              <div className="flex items-center gap-4">
                <ProgressCircle
                  currentIndex={
                    answers.filter((answer) => answer !== null).length
                  }
                  totalQuestions={allQuestions.length}
                />
                {allQuestions.length > 0 && (
                  <>
                    {" "}
                    {console.log(
                      "allqs entering2part 1 for 4 ",
                      allQuestions[activeQuestion]
                    )}
                    <QuestionCard
                      questions={[allQuestions[activeQuestion]]} // Convert to array
                      selectedAnswer={answers[activeQuestion]}
                      handleAnswer={handleAnswer} // Pass handleAnswer function
                      showExplanation={showNextQuestion}
                      showCorrectAnswer={showNextQuestion}
                      skipped={skipped}
                    />
                  </>
                )}
              </div>
              <div className="flex justify-center">
                {!answers[activeQuestion] && (
                  <button
                    onClick={handleSkip}
                    className="bg-gradient-to-r from-[#5899E2] to-pepsi-blue duration-300 transition-colors hover:from-pepsi-blue hover:to-[#5899E2] cursor-pointer text-white px-4 py-2 text-sm rounded-md font-bold w-30"
                  >
                    تخطي السؤال
                  </button>
                )}
              </div>
              <div className="flex justify-between">
                <Navigation
                  totalQuestions={allQuestions.length}
                  currentIndex={activeQuestion}
                  answeredQuestions={answers.map((answer) => answer !== null)}
                  onNavigate={handleNextQuestion}
                />
              </div>
            </div>
          ) : method === "4" && showChapterSelection ? (
            // <div className="flex flex-col space-y-10 w-85 mt-6">
            //   <p className="mb-2 font-medium text-right text-gray-600">
            //     اختر الفصول التي تريد تعلمها:
            //   </p>
            //   <div className="grid  grid-cols-1 gap-2 w-192 ml-auto">
            //     {allChapters.map((chapter) => (
            //       <label
            //         key={chapter}
            //         className="flex items-center cursor-pointer gap-x-2"
            //       >
            //         <input
            //           type="checkbox"
            //           value={chapter}
            //           checked={selectedChapters.includes(chapter)}
            //           onChange={() => handleChapterSelection(chapter)}
            //           className="accent-pepsi-blue"
            //         />
            //         <span className="text-gray-600 whitespace-nowrap">
            //           {"شابتر " +  formatChapter(chapter)}
            //         </span>
            //       </label>
            //     ))}
            //   </div>
            //   <button
            //     onClick={startSecondLearningSession}
            //     className="px-4 py-2 mt-6 text-white transition duration-300 rounded-lg shadow-md bg-pepsi-blue hover:bg-blue-700"
            //   >
            //     ابدأ التعلم
            //   </button>
            // </div>
            <div className="flex flex-col space-y-2 w-85 mt-6">
              <p className="mb-2 font-medium text-right text-gray-600">
                : اختر الفصول التي تريد تعلمها
              </p>
              <div className="grid grid-cols-1 gap-2 w-192 ml-auto">
                {allChapters.map((chapter) => (
                  <label
                    key={chapter}
                    className="flex items-center flex-row-reverse cursor-pointer gap-x-2"
                  >
                    <input
                      type="checkbox"
                      value={chapter}
                      checked={selectedChapters.includes(chapter)}
                      onChange={() => handleChapterSelection(chapter)}
                      className="accent-pepsi-blue"
                    />
                    <span className="text-gray-600 whitespace-nowrap">
                      {"شابتر " + formatChapter(chapter)}
                    </span>
                  </label>
                ))}
              </div>
              <button
                onClick={startSecondLearningSession}
                className="px-4 py-2 mt-6 text-white transition duration-300 rounded-lg shadow-md bg-pepsi-blue hover:bg-blue-700 ml-auto"
              >
                ابدأ التعلم
              </button>
            </div>
          ) : (
            <div className="flex flex-col space-y-4">
              <div className="flex items-center gap-4">
                <ProgressCircle
                  currentIndex={
                    answers.filter((answer) => answer !== null).length
                  }
                  totalQuestions={allQuestions.length}
                />
                {allQuestions.length > 0 && (
                  <QuestionCard
                    questions={[allQuestions[activeQuestion]]} // Convert to array
                    selectedAnswer={answers[activeQuestion]}
                    handleAnswer={handleAnswer} // Pass handleAnswer function
                    showExplanation={showNextQuestion}
                    showCorrectAnswer={showNextQuestion}
                    skipped={skipped}
                  />
                )}
              </div>
              <div className="flex justify-center">
                {!answers[activeQuestion] && (
                  <button
                    onClick={handleSkip}
                    className="bg-gradient-to-r from-[#5899E2] to-pepsi-blue duration-300 transition-colors hover:from-pepsi-blue hover:to-[#5899E2] cursor-pointer text-white px-4 py-2 text-sm rounded-md font-bold w-30"
                  >
                    تخطي السؤال
                  </button>
                )}
              </div>
              <div className="flex justify-between">
                <Navigation
                  totalQuestions={allQuestions.length}
                  currentIndex={activeQuestion}
                  answeredQuestions={answers.map((answer) => answer !== null)}
                  onNavigate={handleNextQuestion}
                />
              </div>
            </div>
          )}

          {isLoading && (
            <div className="flex items-center justify-center mt-4 mb-4">
              <CircularProgress color="primary" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Attempt;
