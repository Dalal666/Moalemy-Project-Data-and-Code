import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import UserTable from "../components/UserTable";

const Admin = () => {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [userMethod, setUserMethod] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        router.replace("/"); // Redirect to home page if storedUser is not defined
      } else {
        const parsedUser = JSON.parse(storedUser);
        if (parsedUser.email !== "admin@email.com") {
          router.replace("/"); // Redirect to home page if user is not admin
        } else {
          setLoading(false);
          setUser(parsedUser);
          setUserMethod(parsedUser.method);
        }
      }
    }
  }, [router]);
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-16 h-16 border-t-4 border-b-4 border-blue-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="w-screen h-screen bg-gradient-to-r from-blue-300 to-white">
      <UserTable />
    </div>
  );
};

export default Admin;