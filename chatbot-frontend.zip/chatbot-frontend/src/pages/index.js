import Login from "@/components/login";
import { Inter } from 'next/font/google'
import withAuthRedirect from '../utils/withAuthRedirect';
const inter = Inter({ subsets: ['latin']  })

import React from 'react';


const Home = () => {
  return (
    <div className={`${inter.className}` }>
      <main className="">
        <Login />
      </main>
    </div>
  );
};

export default withAuthRedirect(Home);