import Dashboard from "@/components/dashboard";
import React, { useEffect, useState } from "react";
import { Inter } from "next/font/google";
import { useRouter } from "next/router";
import { useNextStep } from "nextstepjs";

const inter = Inter({ subsets: ["latin"] });

export default function Index() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  const handleLogout = () => {
    localStorage.removeItem("user");
    router.replace("/");
  };

 

  // Ensure the user is authenticated
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        router.replace("/"); // Redirect to home page if user is not logged in
      } else {
        setLoading(false); // Set loading to false after user check
      }
    }
  }, [router]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-16 h-16 border-t-4 border-b-4 border-blue-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-gradient-to-r from-[#5899E2] to-white flex flex-col"
      style={{ overflow: "hidden" }}
    >
      <Dashboard handleLogout={handleLogout} />

      {/* Close Tour Button (visible only if the tour is running) */}
      
    </div>
  );
}
