

// export default Users;
import axios from "axios";
import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/router";
import { CircularProgress } from "@mui/material";
import { DownloadTableExcel } from "react-export-table-to-excel";
import "react-super-responsive-table/dist/SuperResponsiveTableStyle.css";
import { Table, Tbody, Tr, Td } from "react-super-responsive-table";
import Sidebar from "../../components/sidebar";
import React from "react";
const Users = () => {
  const tableRef = useRef(null);
  const [practiceAttempts, setPracticeAttempts] = useState([]);
  const [error, setError] = useState({ isError: false, msg: "" });
  const [isLoading, setIsLoading] = useState(true);
  const [methods, setMethods] = useState([]);
  const [users, setUsers] = useState([]);
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const { email } = router.query;
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        router.replace("/"); // Redirect to home page if storedUser is not defined
      } else {
        
        const parsedUser = JSON.parse(storedUser);
        if (parsedUser.email !== "admin@email.com") {
          setLoading(true);
          router.replace("/"); // Redirect to home page if user is not admin
        }
        else{ setLoading(false);}
      }
    }
  }, [router]);

  useEffect(() => {
    if (practiceAttempts.length > 0) {
      const methodNames = practiceAttempts.map((attempt) =>
        attempt.method === 1
          ? "Static"
          : attempt.method === 2
          ? "Adaptable"
          : attempt.method === 3
          ? "Adaptive"
          : "Mixed"
      );

      const uniqueMethods = [...new Set(methodNames)];
      setMethods(uniqueMethods);
    }
  }, [practiceAttempts]);

  useEffect(() => {
    if (!email) return;

    const fetchUsers = async () => {
      try {
        const attemptsRes = await axios.get(`https://backend-chatbot.nousheen-solutions.com/api/attempts?email=${email}`);
        setPracticeAttempts(attemptsRes.data);
      } catch (err) {
        console.error(err);
        setError({ isError: true, msg: "An error occurred while fetching attempts." });
      } finally {
        setIsLoading(false);
      }
try{
               const userRes = await axios.post("https://backend-chatbot.nousheen-solutions.com/api/user", { email });
                setUsers(userRes.data);
              } catch (err) {
                console.error(err);
                setError({ isError: true, msg: "An error occurred while fetching user data." });
              } finally {
                setIsLoading(false);
              }
    };

    fetchUsers();
  }, [email]);
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-16 h-16 border-t-4 border-b-4 border-blue-500 rounded-full animate-spin"></div>
      </div>
    );
  }
  return (
    <div className="flex">
      {/* Sidebar - Fixed width */}
      <div className="fixed top-0 left-0 z-10 w-64 h-screen text-white bg-gray-800">
        <Sidebar />
      </div>

      {/* Main Content - Pushed to the right of sidebar */}
      <div className="flex-1 min-h-screen p-6 ml-64 bg-gray-50">
        {!isLoading ? (
          <div className="w-full table-container">
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-700">Student Results</h2>
              <DownloadTableExcel filename="chatbot" sheet="users" currentTableRef={tableRef.current}>
                <button className="px-4 py-2 text-white transition duration-300 bg-blue-500 rounded-md hover:bg-blue-600">
                  Export to Excel
                </button>
              </DownloadTableExcel>
            </div>

            <Table
              ref={tableRef}
              className="w-full overflow-hidden border-collapse rounded-lg shadow-lg"
            >
              <Tbody>
                {/* Student Info */}
                <Tr className="font-medium text-gray-800 bg-blue-100">
                  <Td className="w-1/2 px-4 py-2 border">Student Name</Td>
                  <Td className="w-1/2 px-4 py-2 border">{practiceAttempts[0]?.username}</Td>
                </Tr>
                <Tr className="bg-gray-100">
                  <Td className="w-1/2 px-4 py-2 border">Student Email</Td>
                  <Td className="w-1/2 px-4 py-2 border">{practiceAttempts[0]?.email}</Td>
                </Tr>
                <Tr className="bg-blue-50">
                  <Td className="w-1/2 px-4 py-2 border">Approach Sequence</Td>
                  <Td className="w-1/2 px-4 py-2 border">{methods.join(", ")}</Td>
                </Tr>
                <Tr className="font-medium text-gray-800 bg-blue-100">
                  <Td className="w-1/2 px-4 py-2 border">PreTest</Td>
                  <Td className="w-1/2 px-4 py-2 border">{practiceAttempts[0]?.pretest_score_before                  }</Td>
                </Tr>
                <Tr className="font-medium text-gray-800 bg-blue-100">
                  <Td className="w-1/2 px-4 py-2 border">Weak Chapters</Td>
                  <Td className="w-1/2 px-4 py-2 border">{users[0]?.weak_chapters.join(", ")}</Td>
                </Tr>
                {/* Table Headers */}
                <Tr className="font-bold text-center text-white bg-blue-500">
                  <Td className="px-2 py-2 border">Approach</Td>
                  <Td className="px-2 py-2 border">Post Test</Td>
                  <Td className="px-2 py-2 border">Learning Gain</Td>
                  <Td className="px-2 py-2 border">Relative Gain</Td>
                  <Td className="px-2 py-2 border">Time</Td>
                  <Td className="px-2 py-2 border">Messages</Td>
                  <Td className="px-2 py-2 border">Tasks</Td>
                  <Td className="px-2 py-2 border">Satisfaction</Td>
                  <Td className="px-2 py-2 border">Task Level</Td>
                  <Td className="px-2 py-2 border">Time</Td>
                  <Td className="px-2 py-2 border">Tasks</Td>
                  <Td className="px-2 py-2 border">Errors</Td>
                </Tr>

                {/* Table Content */}
                {practiceAttempts.map((user, index) => (
                  <React.Fragment key={index}>
                    <Tr className="text-center bg-gray-50 hover:bg-gray-100">
                      <Td className="px-2 py-2 border" rowSpan={3}>
                        {user.method === 1
                          ? "Static"
                          : user.method === 2
                          ? "Adaptable"
                          : user.method === 3
                          ? "Adaptive"
                          : "Mixed"}
                      </Td>
                      <Td className="px-2 py-2 border" rowSpan={3}>{user.test_score}</Td>
                      <Td className="px-2 py-2 border" rowSpan={3}>
                        {user.test_score - user.pretest_score_before}
                      </Td>
                      <Td className="px-2 py-2 border" rowSpan={3}>
                        {Math.round(
                          ((user.test_score - user.pretest_score_before) /
                            (10 - user.pretest_score_before)) *
                            100
                        )}
                      </Td>
                      <Td className="px-2 py-2 border" rowSpan={3}>{user.time_taken_easy + user.time_taken_hard + user.time_taken_medium}</Td>
                      <Td className="px-2 py-2 border" rowSpan={3}>{user.number_of_questions * 2}</Td>
                      <Td className="px-2 py-2 border" rowSpan={3}>{user.number_of_attempted_questions}</Td>
                      <Td className="px-2 py-2 border" rowSpan={3}>{user.satisfaction}</Td>
                      <Td className="px-2 py-2 border">سهل</Td>
                      <Td className="px-2 py-2 border">{user.time_taken_easy}</Td>
                      <Td className="px-2 py-2 border">{user.tasks_easy}</Td>
                      <Td className="px-2 py-2 border">{user.errors_easy}</Td>
                    </Tr>
                    <Tr className="text-center bg-gray-100">
                      <Td className="px-2 py-2 border">متوسط</Td>
                      <Td className="px-2 py-2 border">{user.time_taken_medium}</Td>
                      <Td className="px-2 py-2 border">{user.tasks_medium}</Td>
                      <Td className="px-2 py-2 border">{user.errors_medium}</Td>
                    </Tr>
                    <Tr className="text-center bg-gray-50">
                      <Td className="px-2 py-2 border">صعب</Td>
                      <Td className="px-2 py-2 border">{user.time_taken_hard}</Td>
                      <Td className="px-2 py-2 border">{user.tasks_hard}</Td>
                      <Td className="px-2 py-2 border">{user.errors_hard}</Td>
                    </Tr>
                  </React.Fragment>
                ))}
              </Tbody>
            </Table>
          </div>
        ) : (
          <div className="flex items-center justify-center h-32">
            <CircularProgress />
          </div>
        )}
        {error.isError && (
          <div className="text-center alert-danger">
            <p>{error.msg}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Users;