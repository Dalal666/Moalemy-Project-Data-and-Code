import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { useRouter } from "next/router";
import { LuClock4 } from "react-icons/lu";
import { CircularProgress } from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import { pretestQuestions } from "../data/CourseData";
import { Navigation } from "../components/navigation";
import QuestionCard from "../components/questionCard";
import { ProgressCircle } from "../components/progressCircle";
import { useNextStep } from "nextstepjs";

const satisfactionQuestions = [
  "أنا راضية جدًا عن طريقة التعلم؟",
  "أعتقد انني سأرغب في استخدام النظام في ظل هذا الأسلوب التعليمي بشكل متكرر",
  "وجدت ان النظام في ظل هذا الاسلوب التعليمي معقد بشكل غير ضروري",
  "وجدت ان النظام في ظل هذا الاسلوب التعليمي سهل الفهم والاستخدام.",
  "اعتقد انني احتاج الى دعم من معلم لكي اتمكن من استخدام النظام في ظل هذا الأسلوب التعليمي بفعالية",
  "وجدت ان الوظائف المختلفه في النظام في ظل هذا الاسلوب التعليمي كانت متكامله بشكل جيد",
  "اعتقد ان هناك متناقضات كثيره في النظام في ظل هذا الاسلوب التعليمي",
  "اعتقد ان معظم المتعلمون سيتعلمون بسرعة باستخدام النظام في ظل هذا الاسلوب التعليمي",
  "وجدت ان استخدام النظام في ظل هذا الاسلوب التعليمي كان معقدًا جدًا",
  "شعرت بالثقه اثناء استخدام النظام في ظل هذا الاسلوب التعليمي",
  "كنت بحاجة لتعلم الكثير من الاشياء قبل ان اتمكن من استخدام النظام في ظل هذا الاسلوب التعليمي بفعالية",
];
const satisfactionChoices = [
  "١ غير موافقة جدًا",
  "٢ غير موافقة",
  "٣ محايدة",
  "٤ موافقة",
  "٥ موافقة جدًا",
];

const PostTest = () => {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [satisfactionMessages, setSatisfactionMessages] = useState([
    satisfactionQuestions[0],
  ]);
  const [satisfactionResponses, setSatisfactionResponses] = useState([]);
  const [valid, setValid] = useState(false);
  const [checkUserStatus, setCheckUserStatus] = useState(true);
  const messagesEndRef = useRef();
  const [activeQuestion, setActiveQuestion] = useState(0);
  const [userMethod, setUserMethod] = useState(null);
  const [currentSatisfactionQuestion, setCurrentSatisfactionQuestion] =
    useState(0);
  const [messages, setMessages] = useState([]);
  const [score, setScore] = useState(0);
  const [satis, setSatis] = useState(null);
  const [showStatus, setShowStatus] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [postTestDone, setPostTestDone] = useState(false);
  const [endMsg, setEndMsg] = useState(false);
  const [showSatisfactionPage, setShowSatisfactionPage] = useState(false);
  const [isLoading, setisLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(200);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [error, setError] = useState({
    isError: false,
    msg: "",
  });
  const [loading, setLoading] = useState(true);
  const { startNextStep, closeNextStep, currentTour } = useNextStep();

  useEffect(() => {
      startNextStep("postTestTour");
  }, [startNextStep]);

  // if show satisfaction step is true then show satisfaction tour
  useEffect(() => {
    if (showSatisfactionPage) {
      startNextStep("surveyTour");
    }
  }, [showSatisfactionPage]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        router.replace("/"); // Redirect to home page if storedUser is not defined
      } else {
        setLoading(false); // Set loading to false after user is set
      }
    }
  }, [router]);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    const postTestValid = JSON.parse(localStorage.getItem("post_test"));
    if (!postTestValid) {
      alert("أنت غير مسموح لك بالدخول إلى هذه الصفحة");
      router.replace("/dashboard");
    } else {
      setValid(postTestValid);
      setUser(storedUser);
      setUserMethod(+storedUser.method);
      setSatis(storedUser.user_satis);

      // Randomize questions of pretest without changing the original array
      const tempQuestions = [...pretestQuestions];
      const randomizedQuestions = tempQuestions.sort(() => Math.random() - 0.5);
      setQuestions(randomizedQuestions);
      setMessages([randomizedQuestions[0]]);
    }
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const onSelectAnswer = async (choice) => {
    const currentQuestion = questions[activeQuestion];

    console.log("Selected choice:", choice);
    console.log("CURRENT QUESTION ANSWER ", currentQuestion.answer);
    console.log(currentQuestion.choices[currentQuestion.answer]);
    if (currentQuestion.choices[currentQuestion.answer] == choice) {
      setScore((state) => state + 1);
    }

    if (questions.length > activeQuestion + 1) {
      setActiveQuestion((state) => state + 1);
      setMessages((state) => [...state, questions[activeQuestion + 1]]);
    } else {
      console.log("done");
      console.log(user.progress);

      try {
        console.log("test_score", score);
        const res = await axios.put(
          "https://backend-chatbot.nousheen-solutions.com/api/update_attempt",
          {
            email: user.email,
            test_score: score + 1,
            satisfaction: 0,
          }
        );
        user["progress"] = 10;

        setisLoading(false);
        setShowStatus(true);
        setShowSatisfactionPage(true);
      } catch (error) {
        setisLoading(false);
        setError({ isError: true, msg: "!حدث خطأ ما" });
        console.error("Update failed:", error);
      }
      scrollToBottom();
    }
  };

  const handleSelectSatis = async (answerValue) => {
    console.log(
      "Current Satisfaction Question Index:",
      currentSatisfactionQuestion
    );
    setisLoading(true);

    try {
      console.log("entered in try");
      // Update the response for the current satisfaction question
      const updatedResponses = [...satisfactionResponses];
      updatedResponses[currentSatisfactionQuestion] = answerValue;
      setSatisfactionResponses(updatedResponses);

      // If it's the last satisfaction question, send all responses to the server
      const finalData = [...updatedResponses];
      console.log("satisfaction question length", satisfactionQuestions.length);
      console.log("current question", currentSatisfactionQuestion);
      if (currentSatisfactionQuestion === satisfactionQuestions.length - 1) {
        console.log("entered in if");
        const attempt_pk = localStorage.getItem("attempt_pk");
        const satisfactionData = {
          email: user.email,
          responses: JSON.stringify(finalData),
          practice_attempt: attempt_pk,
          user_method: userMethod,
          post_test_score: score + 1,
        };

        setEndMsg(true);
        const response = await axios.post(
          "https://backend-chatbot.nousheen-solutions.com/api/create_satisfaction",
          satisfactionData
        );
        console.log(await response.data);

        user["progress"] = 10;
        setSatis(answerValue);
        setPostTestDone(true);
        setShowResult(true);

        setTimeout(() => {
          router.replace("/dashboard");
        }, 5000);
      } else {
        // Move to the next satisfaction question
        setSatisfactionMessages((prevMessages) => [
          ...prevMessages,
          satisfactionQuestions[currentSatisfactionQuestion + 1],
        ]);
        setCurrentSatisfactionQuestion((state) => state + 1);
      }

      setisLoading(false);
    } catch (error) {
      setisLoading(false);
      setError({ isError: true, msg: "!حدث خطأ ما" });
      console.error("Update failed:", error);
    }

    console.log("Scrolling to bottom");
    setTimeout(scrollToBottom, 100);
  };

  useEffect(() => {
    if (
      satisfactionResponses.length === satisfactionQuestions.length &&
      satisfactionResponses.every((response) => response !== undefined)
    ) {
      submitReStudy();
    }
  }, [satisfactionResponses]);
  const submitReStudy = async () => {
    setisLoading(true);
    setError({ isError: false, msg: "" });
    try {
      const response = await axios.put("https://backend-chatbot.nousheen-solutions.com/api/update", {
        email: user.email,
        username: user.username,
        password: user.password,
        method: userMethod,
        session: user.session + 1,
      });
      user["progress"] = 0;
      localStorage.setItem("user", JSON.stringify(response.data));
      localStorage.removeItem("post_test");
      router.replace("/dashboard");
    } catch (error) {
      setError({ isError: true, msg: "حدث خطأ ما!" });
      console.error(" failed:", error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    router.replace("/");
  };

  // Scroll to last message
  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
      });
    }
  };

  // change messages to other changed array
  useEffect(scrollToBottom, [endMsg, messages, showResult]);

  useEffect(() => {
    // If time_start is greater than 3 hours, logout
    const timeStart = JSON.parse(localStorage.getItem("time_start"));
    const currentTime = new Date().getTime();
    console.log(currentTime - timeStart);
    if (currentTime - timeStart > 10800000) {
      localStorage.clear();
      router.replace("/");
    } else {
      setCheckUserStatus(false);
    }
  }, [checkUserStatus]);

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-16 h-16 border-t-4 border-b-4 border-blue-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-gradient-to-r from-[#5899E2] to-white flex flex-col items-center justify-center"
      style={{ overflow: "hidden" }}
    >
      <div className="flex justify-end w-full p-4">
        <li className="list-none">
          <button
            onClick={handleLogout}
            className="px-4 py-2 text-white transition duration-300 bg-gray-700 rounded-md hover:bg-gray-600"
          >
            Logout
          </button>
        </li>
      </div>
      <div className="flex items-center justify-center flex-grow w-full pb-20">
        <div className='flex flex-col justify-between max-w-2xl w-[800px] p-6 space-y-4 shadow-lg bg-white bg-[url("/looper.svg")] bg-left h-[500px] rounded-lg'>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-x-1">
              <LuClock4 className="text-2xl leading-none" />
              <div className="flex flex-col font-semibold">
                <span className="text-sm font-bold leading-5">
                  {formatTime(timeElapsed)}
                </span>
              </div>
            </div>
          </div>

          {!showSatisfactionPage ? (
            <div className="flex flex-col space-y-4">
              <div className="flex items-center gap-4">
                <ProgressCircle
                  currentIndex={activeQuestion}
                  totalQuestions={questions.length}
                />
                <QuestionCard
                  questions={[questions[activeQuestion]]}
                  selectedAnswer={satisfactionResponses[activeQuestion]}
                  handleAnswer={(e) => onSelectAnswer(e)}
                  showExplanation={false}
                />
              </div>
              <Navigation
                totalQuestions={questions.length}
                currentIndex={activeQuestion}
                answeredQuestions={satisfactionResponses.map(
                  (response) => response !== undefined
                )}
                onNavigate={setActiveQuestion}
                isPostTest={true} // Pass isPostTest prop
              />
            </div>
          ) : (
            <div className="flex flex-col space-y-4">
              <div className="flex items-center gap-4">
                <ProgressCircle
                  currentIndex={currentSatisfactionQuestion}
                  totalQuestions={satisfactionQuestions.length}
                />
                <QuestionCard
                  questions={[
                    {
                      content:
                        satisfactionMessages[currentSatisfactionQuestion],
                      choices: satisfactionChoices,
                    },
                  ]}
                  selectedAnswer={
                    satisfactionResponses[currentSatisfactionQuestion]
                  }
                  handleAnswer={handleSelectSatis}
                  showExplanation={false}
                />
              </div>
              <Navigation
                totalQuestions={satisfactionQuestions.length}
                currentIndex={currentSatisfactionQuestion}
                answeredQuestions={satisfactionResponses.map(
                  (response) => response !== undefined
                )}
                onNavigate={setCurrentSatisfactionQuestion}
                isPostTest={true}
              />
            </div>
          )}

          {isLoading && (
            <div className="flex items-center justify-center mt-4 mb-4">
              <CircularProgress color="primary" />
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      {currentTour && (
        <button
          onClick={closeNextStep}
          className="fixed bottom-4 right-4 z-50 p-2 bg-red-500 text-white rounded-full shadow-md"
          style={{ marginRight: "20px" }}
        >
          جولة قريبة
        </button>
      )}
    </div>
  );
};

export default PostTest;
