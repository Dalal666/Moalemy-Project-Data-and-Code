
"use client"; // Required for Next.js App Router

import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import dynamic from "next/dynamic";
import * as XLSX from "xlsx";
import { CircularProgress } from "@mui/material";
import { useRouter } from "next/router";
import Sidebar from "../components/sidebar"; // Ensure correct import path
import "ag-grid-community/styles/ag-theme-alpine.css";
import { ModuleRegistry } from "ag-grid-community";
import {
  ClientSideRowModelModule,
  CellStyleModule,
  TextFilterModule,
  NumberFilterModule,
  ValidationModule,
} from "ag-grid-community";

// Register the required modules
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  CellStyleModule,
  TextFilterModule,
  NumberFilterModule,
  ValidationModule,
]);

// Correct import of AgGridReact
const AgGridReact = dynamic(
  () => import("ag-grid-react").then((module) => module.AgGridReact),
  { ssr: false }
);

// Satisfaction questions and mappings
const METHODS = {
  1: "Static",
  2: "Adaptable",
  3: "Adaptive",
  4: "Mixed",
};

const LEVEL = {
  "٥": 5,
  "٤": 4,
  "٣": 3,
  "٢": 2,
  "١": 1,
};

const Satisfaction = () => {
  const router = useRouter();
  const satisfactionTable = useRef(null);
  const [satisfactions, setSatisfactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState({ isError: false, msg: "" });
const [loading, setLoading] = useState(true);
   useEffect(() => {
      if (typeof window !== "undefined") {
        const storedUser = localStorage.getItem("user");
        if (!storedUser) {
          router.replace("/"); // Redirect to home page if storedUser is not defined
        } else {
          
          const parsedUser = JSON.parse(storedUser);
          if (parsedUser.email !== "admin@email.com") {
            setLoading(true);
            router.replace("/"); // Redirect to home page if user is not admin
          }
          else{ setLoading(false);}
        }
      }
    }, [router]);
 
  useEffect(() => {
    const fetchSatisfactions = async () => {
      try {
        const res = await axios.get("https://backend-chatbot.nousheen-solutions.com/api/satisfaction");
        const users = await axios.get("https://backend-chatbot.nousheen-solutions.com/api/users");

        res.data.forEach((satisfaction) => {
          const user = users.data.find((user) => user.email === satisfaction.user);
          satisfaction.user = user ? user.username : "Unknown User";
          satisfaction.responses = JSON.parse(satisfaction.responses);
        });

        setSatisfactions(res.data);
      } catch (err) {
        console.error(err);
        setError({ isError: true, msg: "Error fetching satisfaction data!" });
      } finally {
        setIsLoading(false);
      }
    };

    fetchSatisfactions();
  }, []);

  const formatSatisfactionData = (data) => {
    return data.map((satisfaction) => ({
      user: satisfaction.user,
      userMethod: METHODS[satisfaction.user_method],
      satisfaction: LEVEL[satisfaction.responses[0].split(" ")[0]],
      useAgain: LEVEL[satisfaction.responses[1].split(" ")[0]],
      complex: LEVEL[satisfaction.responses[2].split(" ")[0]],
      easyToUse: LEVEL[satisfaction.responses[3].split(" ")[0]],
      needIT: LEVEL[satisfaction.responses[4].split(" ")[0]],
      integrated: LEVEL[satisfaction.responses[5].split(" ")[0]],
      inconsistency: LEVEL[satisfaction.responses[6].split(" ")[0]],
      learnability: LEVEL[satisfaction.responses[7].split(" ")[0]],
      cumbersome: LEVEL[satisfaction.responses[8].split(" ")[0]],
      confident: LEVEL[satisfaction.responses[9].split(" ")[0]],
      needToLearn: LEVEL[satisfaction.responses[10].split(" ")[0]],
    })).filter((satisfaction) => Object.values(satisfaction).every((value) => value !== null && value !== undefined ));;
  };

  const columnDefs = [
    { headerName: "User", field: "user" },
    { headerName: "User Method", field: "userMethod" },
    { headerName: "Satisfaction", field: "satisfaction" },
    { headerName: "Use Again", field: "useAgain" },
    { headerName: "Complex", field: "complex" },
    { headerName: "Easy to Use", field: "easyToUse" },
    { headerName: "Need IT", field: "needIT" },
    { headerName: "Integrated", field: "integrated" },
    { headerName: "Inconsistency", field: "inconsistency" },
    { headerName: "Learnability", field: "learnability" },
    { headerName: "Cumbersome", field: "cumbersome" },
    { headerName: "Confident", field: "confident" },
    { headerName: "Need to Learn", field: "needToLearn" },
  ];

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(formatSatisfactionData(satisfactions));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Satisfaction Data");
    XLSX.writeFile(workbook, "SatisfactionData.xlsx");
  };

  return (
    <div className="flex h-screen">
  <div className="w-64 h-screen text-white bg-gray-800">
        <Sidebar />
      </div>
      <div className="flex flex-col flex-1 min-h-screen p-6 bg-gradient-to-r from-gray-100 to-gray-50">
        {isLoading ? (
          <div className="flex items-center justify-center h-96">
            <CircularProgress size={80} />
          </div>
        ) : (
          <div className="p-6 bg-white rounded-lg shadow-lg">
            {/* Header and Export Button */}
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-bold text-gray-700">Satisfaction Data</h1>
              <button
                onClick={exportToExcel}
                className="px-5 py-2 text-white bg-blue-500 rounded-lg shadow-md hover:bg-blue-600"
              >
                Export to Excel
              </button>
            </div>

            {/* AG Grid Table */}
            <div
              className="ag-theme-alpine"
              style={{ height: "calc(100vh - 200px)", width: "100%" }}
            >
              <AgGridReact
                rowData={formatSatisfactionData(satisfactions)}
                columnDefs={columnDefs}
                modules={[ClientSideRowModelModule, ValidationModule]}
                defaultColDef={{
                  flex: 1,
                  minWidth: 100,
                  resizable: true,
                  filter: true,
                  sortable: true,
                }}
                pagination={true}
                paginationPageSize={10}
              />
            </div>
          </div>
        )}

        {/* Error Message */}
        {error.isError && (
          <p className="mt-4 font-semibold text-center text-red-500">{error.msg}</p>
        )}
      </div>
    </div>
  );
};

export default Satisfaction;