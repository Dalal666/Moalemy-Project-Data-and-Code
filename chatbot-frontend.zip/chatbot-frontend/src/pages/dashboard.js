import CardsScreen from '@/components/cardsScreen'
import React, { useEffect } from 'react';
import { Inter } from 'next/font/google'
import Link from "next/link";
import { useRouter } from "next/router";
const inter = Inter({ subsets: ['latin']  })
export default function index() {
  const router = useRouter();

  const handleLogout = () => {
    localStorage.removeItem("user");
    router.replace("/");
  };
  useEffect(() => {
    // Apply overflow hidden to html and body to prevent scrolling
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';

    // Cleanup function to reset overflow when component unmounts
    return () => {
      document.documentElement.style.overflow = '';
      document.body.style.overflow = '';
    };
  }, []);
  return (
    <div className="min-h-screen bg-gradient-to-r from-[#5899E2] to-white flex flex-col">
<div className="w-full flex justify-end p-4">
        <button
          onClick={handleLogout}
          className="bg-gray-700 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition duration-300"
        >
          Logout
        </button>
      </div>
    <div  className="flex items-center bg-gradient-to-r from-[#5899E2]  to-white justify-center min-h-screen h-full">
        <CardsScreen/>
    </div>
    </div>
  )
}
